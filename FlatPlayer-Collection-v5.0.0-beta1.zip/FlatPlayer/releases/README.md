# 发布包

当前版本：

- `FlatPlayer-5.0.0-beta1.apk`（versionCode 73，release 签名）

历史版本在总结合集的 `archive/` 目录：

- `FlatPlayer-5.0.0-alpha3b.apk`
- `FlatPlayer-5.0.0-alpha1b.apk`（已知启动崩溃，仅留档，不建议安装）

这些历史 APK 使用 debug 签名，与 beta1 release 签名不同，不能直接覆盖安装。

建议每个版本附一个 `notes.md`，写清版本号、构建日期和主要变化。
