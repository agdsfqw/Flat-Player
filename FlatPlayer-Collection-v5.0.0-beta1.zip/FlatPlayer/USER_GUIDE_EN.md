# Flat Player User Guide (beta1)

## First launch

1. Tap "Choose folders"
2. Pick a music folder with the system picker
3. Wait for the scan

Only the folders you select are read. Tracks shorter than 30 seconds are ignored.

## Library

- Songs are sorted by title; switch to recent, albums or artists
- The search icon opens a dedicated search page for songs, artists, albums and history; Pinyin and initials work for Chinese
- The locate button jumps to the current song when it is in the current list
- Long-press a song: play only this, play next, audio info, add to playlist, hide, multi-select, edit tags
- Multi-select supports batch add to playlist, play next and removing indexes

## Playlists

- Only user-created playlists; smart playlists were removed
- Create, rename, delete, export M3U and add songs in bulk
- Playlist details also have a locate-current button

## Player

- Slides up and fades in from the mini bar or list; slides down when closing
- Play button has ripple and press-scale feedback
- Long-press the title: audio info, bookmarks, A-B loop, lyric offset, cover preview, quick settings
- Quick settings adjust lyric font size and background blur
- Compact layout is applied automatically in split-screen, small windows and narrow landscape

## Settings

1. **Personalization**: light/dark/system, backgrounds, accent hue, acrylic/frosted glass, four animation levels, presets, reset
2. **Player page**: lyric size, background blur, fade transition, reduce motion
3. **Audio**: equalizer (presets + custom bands), resume, audio focus
4. **Audio files**: folders, hidden songs, duplicates, backup & restore, cleanup
5. **Language & accessibility**: system language, color-blind grayscale, font scale

## Backup and restore

Settings → Audio files → Backup & restore:

- Export JSON: settings, playlists, legacy favorites data, custom covers
- Restore: compatible with Flat Player and Sfl Player 4.1.3 backups
- Cleanup removes indexes whose files no longer exist

Restoring overwrites current data; confirm before continuing.

## Notifications

- Media notification while playing, with the Flat Player waveform icon
- Android 13+ requires notification permission
- Previous, play/pause and next actions are available

## Privacy

- No network permission
- No data collection or upload
- Only reads audio and matching lyrics from folders you select with SAF

## FAQ

**Library is empty?**  
You must pick a folder on first launch. Flat Player does not scan the whole device.

**Short tracks are missing?**  
Tracks shorter than 30 seconds are filtered out.

**How do I migrate from the old alpha?**  
Export a backup in the old version, uninstall it, install beta1, then restore. beta1 uses a new release signature and cannot update over alpha directly.
