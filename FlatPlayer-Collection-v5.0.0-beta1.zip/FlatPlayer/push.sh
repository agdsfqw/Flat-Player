#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "Flat Player 上传到 GitHub"
read -r -p "GitHub 用户名: " GH_USER
read -r -p "GitHub 邮箱: " GH_EMAIL
read -r -p "仓库名（回车默认 FlatPlayer）: " REPO
REPO=${REPO:-FlatPlayer}
read -r -s -p "Token（输入不显示）: " TOKEN
echo
[ -n "$GH_USER" ] && [ -n "$TOKEN" ] || { echo "用户名或 Token 为空"; exit 1; }
git init
git config user.name "$GH_USER"
git config user.email "$GH_EMAIL"
git add .
git commit -m "Flat Player 5.0.0-alpha3b" || true
git branch -M main
git remote remove origin 2>/dev/null || true
git remote add origin "https://github.com/$GH_USER/$REPO.git"
ASK="$PWD/.askpass.sh"
cat > "$ASK" <<'A'
#!/bin/sh
case "$1" in *Username*) echo "$GH_USER" ;; *) echo "$TOKEN" ;; esac
A
chmod +x "$ASK"
export GH_USER TOKEN
GIT_ASKPASS="$ASK" GIT_TERMINAL_PROMPT=0 git push -u origin main && echo "完成：https://github.com/$GH_USER/$REPO"
rm -f "$ASK"
