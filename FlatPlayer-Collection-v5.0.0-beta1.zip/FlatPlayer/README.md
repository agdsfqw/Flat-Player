# Flat Player

一个低负载、扁平化风格的本地 Android 音乐播放器。  
Sfl Player 4.1.3 的下一代重构版本，当前为 **v5.0.0-beta1**。

- 包名：`com.flatplayer.neo`
- 应用名：Flat Player
- 最低支持：Android 6.0（API 23）
- 无第三方库 · 无联网权限 · 无广告

> 当前是 beta 候选版，进入回归测试阶段。稳定版请使用 Sfl Player 4.1.3。

## 下载

- **最新 APK**：见仓库 **Releases** 页面或 `releases/FlatPlayer-5.0.0-beta1.apk`
- 更新记录：`CHANGELOG.md`
- 源码与构建脚本在本仓库根目录

## 已有功能

### 播放

- 本地音频播放、后台服务、通知栏
- 顺序 / 单曲循环 / 随机
- 倍速、均衡器、淡化切换、睡眠定时、A-B 循环
- 书签、长音频续播

### 曲库

- **只读取 SAF 手动选择的文件夹**，不扫描整机
- 自动过滤时长 <30 秒的音频
- 文件夹勾选、隐藏、最近播放、统计
- M3U、重复检测
- 格式与音质徽标

### 界面

- 浅色 / 深色 / 跟随系统
- 6 套底色、360 档强调色
- 材质二选一：亚克力 / 毛玻璃
- 动画四档、四个性能预设、一键重置
- 播放页：歌词字号、背景模糊开关、播放键波纹与回弹
- 小窗 / 分屏紧凑布局
- 独立搜索页（歌曲 / 歌手 / 专辑 / 历史 / 拼音）
- 平板双栏、4×2 小部件

## 设置结构

抽屉 → 设置：

1. 个性化
2. 播放页面
3. 音频设置（含均衡器）
4. 音频文件管理（含备份与恢复）
5. 语言与无障碍

## 安装

1. 下载 `releases/FlatPlayer-5.0.0-beta1.apk`
2. 允许安装未知应用
3. 首次启动点「选择文件夹」，通过 SAF 选择音乐目录

beta1 使用 release 签名，不能直接覆盖旧 alpha。升级前请先在旧版导出备份，
卸载旧版后安装，再恢复备份。

Flat Player 与 Sfl Player 包名不同，可以同时安装，但数据不互通。

## 构建

不使用 Gradle，直接用 Android SDK 工具构建：

```bash
export ANDROID_SDK_ROOT=/path/to/android-sdk
export JAVA_HOME=/path/to/jdk17
./build.sh
```

产物：`FlatPlayer.apk`。版本号以 `AndroidManifest.xml` 为唯一来源。

## 目录

```
src/                  Java 源码
res/                  布局与资源
assets/               应用内使用指南
releases/             发布 APK
build.sh              手动构建脚本
push.sh               手机上传辅助脚本
CHANGELOG.md          beta / alpha 更新记录
ROADMAP.md            后续计划
BUILDING.md           构建说明
TESTING.md            测试清单
USER_GUIDE.md         中文使用指南
USER_GUIDE_EN.md      English user guide
SECURITY.md           安全说明
RELEASE_SIGNING.md    发布签名说明
MAINTAINING.md        维护手册
```

## 隐私

- 不申请联网权限
- 不收集、不上传任何数据
- 只读取用户通过 SAF 选择的音频与同名歌词

## 许可

免费使用，不可用于盈利。转载或分发请保留作者信息与本声明。

Copyright © 2026 agdsfqw / 蓝色大肥鱼

- 制作：agdsfqw
- 协助：蓝色大肥鱼（DeepSeek）
