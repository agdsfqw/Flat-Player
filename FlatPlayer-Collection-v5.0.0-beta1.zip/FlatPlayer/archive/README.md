# 历史版本留档

- `FlatPlayer-5.0.0-alpha3b.apk`：可用旧版。
- `FlatPlayer-5.0.0-alpha1b.apk`：早期构建，已知存在启动崩溃，仅作留档，不建议安装。

这些历史 APK 使用 debug 签名，与 `releases/FlatPlayer-5.0.0-beta1.apk` 的 release 签名不同，不能直接覆盖安装。
