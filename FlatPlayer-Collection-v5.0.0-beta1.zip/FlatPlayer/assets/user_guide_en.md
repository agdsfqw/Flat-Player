# Flat Player Guide (beta1)

## First launch

1. Tap "Choose folders"
2. Pick a music folder with the system picker
3. Wait for the scan

Only selected folders are read. Tracks shorter than 30 seconds are ignored.

## Search

Tap the search icon at the top right. Songs, artists, albums and history are supported; Pinyin and initials work for Chinese.

## Settings

Five modules: Personalization, Player page, Audio, Audio files, Language & accessibility.

The equalizer lives under Audio; backup and restore live under Audio files.

## Player

- Play button has ripple and press-scale feedback
- Long-press the title for audio info, bookmarks, A-B loop, lyric offset and cover preview
- Compact layout is applied automatically in split-screen or small windows
