# 发布签名

beta1 起使用独立 release keystore，不再使用 debug key。

## 本机位置

- keystore：`/root/软件1/FlatPlayer-release.keystore`
- 凭据：`/root/软件1/FlatPlayer-release-credentials.txt`

**这两个文件必须自己备份，不能丢失，也不能上传到 GitHub。**  
丢失后无法再发布可覆盖安装的新版本。

## 构建

```bash
export RELEASE_KS=/path/to/FlatPlayer-release.keystore
export RELEASE_KS_PASS='你的密码'
export RELEASE_ALIAS=flatplayer
export RELEASE_KEY_PASS='你的密码'
./build.sh
```

未设置 `RELEASE_KS` 时仍回退到 debug 签名。

## 注意

- beta1 release 与之前 alpha 的 debug 签名不同，**旧版无法直接覆盖安装**
- 升级前先在旧版「备份与恢复」里导出 JSON
- 卸载旧版，安装 beta1，再恢复备份
