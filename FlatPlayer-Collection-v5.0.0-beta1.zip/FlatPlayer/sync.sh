#!/usr/bin/env bash
# 一键同步源码到已配置的 GitHub 仓库（电脑或 Termux）
set -e
cd "$(dirname "$0")"

if ! git remote get-url origin >/dev/null 2>&1; then
    echo "还没有配置远程仓库。先执行："
    echo "  git remote add origin https://github.com/你的用户名/FlatPlayer.git"
    exit 1
fi

git add -A
if git diff --cached --quiet; then
    echo "没有新的改动需要提交。"
else
    git commit -m "sync: $(date '+%Y-%m-%d %H:%M')"
fi

git pull --rebase origin main || true
git push origin main
echo "同步完成：$(git remote get-url origin)"
