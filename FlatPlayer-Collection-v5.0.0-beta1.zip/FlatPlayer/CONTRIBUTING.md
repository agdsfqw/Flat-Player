# 贡献

## 构建

```bash
export ANDROID_SDK_ROOT=/path/to/android-sdk
export JAVA_HOME=/path/to/jdk17
./build.sh
```

不使用 Gradle，详见 `BUILDING.md`。

## 提交

- 一个 PR 只做一件事
- 说明复现步骤、修改点、测试方式
- 不要提交 `debug.keystore`、`build/`、`.apk`（发布包除外）

## 代码风格

- Java 8 语法，不使用 lambda（当前构建方式不支持）
- 不引入第三方库，除非在 PR 中说明体积与必要性
- 新增文案必须同时提供 `values` 与 `values-en`

## 测试

按 `TESTING.md` 至少跑一遍相关项，并在 PR 里写明结果。
