# 维护手册

## 分支

| 分支 | 用途 |
|---|---|
| `main` | Flat Player 5.x 开发 |
| `beta/*` | beta 回归与修复（可选） |

Sfl Player 4.1.x LTS 在独立仓库维护，不在本项目内。

## 发版清单（5.x）

1. 修改 `AndroidManifest.xml` 的 `versionCode` / `versionName`
2. 更新 `CHANGELOG.md`、`README.md` 版本
3. 设置 `RELEASE_KS` 等环境变量，执行 `./build.sh`
4. `apksigner verify --print-certs FlatPlayer.apk`
5. 按 `TESTING.md` 做回归
6. 打 tag：`git tag v5.0.0-beta1 && git push --tags`
7. GitHub Releases：附 `FlatPlayer-5.0.0-beta1.apk`，写更新说明
8. 重新生成总结合集包

## 签名

- 仓库不提交 release keystore 与密码
- 固定 keystore，丢失后无法发布可覆盖安装的新版本
- 更换密钥必须提前说明，用户需卸载重装
- 详见 `RELEASE_SIGNING.md`

## Issue 处理

优先修复：

1. 崩溃 / 数据损坏
2. 无法启动 / 无法播放
3. 备份恢复失败
4. 新 Android 版本兼容

可以延后：

- 新功能建议
- UI 偏好
- 已明确排除的范围（见 ROADMAP）

## 兼容性

- minSdk 23
- targetSdk 34
- 包名固定 `com.flatplayer.neo`
- 与 Sfl Player 4.1.3 的备份 JSON 保持兼容
- 改动数据结构时，保持旧备份可读或明确提示
