package com.flatplayer.neo;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.widget.TextView;

/** 无封面时的占位：按名字取色 + 首字。 */
public final class Tiles {

    private static final int[] PALETTE = {
            0xFF5B8CFF, 0xFFE0685B, 0xFF4CAF7D, 0xFFB06BD8,
            0xFFE0A33B, 0xFF3BA9B8, 0xFFD86B9E, 0xFF6B7BD8
    };

    private Tiles() {
    }

    public static int colorFor(String text) {
        String value = text == null ? "" : text;
        int index = Math.abs(value.hashCode()) % PALETTE.length;
        return PALETTE[index];
    }

    public static String initial(String text) {
        String value = text == null ? "" : text.trim();
        if (value.isEmpty()) {
            return "?";
        }
        return value.substring(0, 1).toUpperCase();
    }

    /** 方形（圆角）或圆形占位。 */
    public static void apply(TextView view, String text, boolean circle) {
        view.setText(initial(text));
        view.setTextColor(Color.WHITE);
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(colorFor(text));
        if (circle) {
            drawable.setShape(GradientDrawable.OVAL);
        } else {
            drawable.setCornerRadius(view.getResources().getDisplayMetrics().density * 14);
        }
        view.setBackground(drawable);
    }
}
