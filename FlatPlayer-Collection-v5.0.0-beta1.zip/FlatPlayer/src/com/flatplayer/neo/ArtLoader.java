package com.flatplayer.neo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;

import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 封面异步加载 + 内存 LRU。列表小图与播放页大图共用。 */
public final class ArtLoader {

    public interface Callback {
        void onArt(String uri, Bitmap bitmap);
    }

    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(2);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static LruCache<String, Bitmap> cache;

    private ArtLoader() {
    }

    private static Bitmap decodeFile(File file, int target) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
            int sample = 1;
            int width = Math.max(1, bounds.outWidth);
            while (width / (sample * 2) >= target) {
                sample *= 2;
            }
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sample;
            return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
        } catch (Throwable t) {
            return null;
        }
    }

    private static volatile int saveCount;

    private static void saveFile(File file, Bitmap bitmap) {
        try {
            FileOutputStream out = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out);
            out.close();
            if (++saveCount % 20 == 0) {
                prune(file.getParentFile());
            }
        } catch (Throwable ignored) {
            // 缓存写失败不影响显示
        }
    }

    /** 磁盘缓存上限 64MB，超出后按最久未访问删除。 */
    private static void prune(File dir) {
        File[] files = dir == null ? null : dir.listFiles();
        if (files == null || files.length == 0) {
            return;
        }
        long total = 0;
        for (File file : files) {
            total += file.length();
        }
        if (total <= 64L * 1024 * 1024) {
            return;
        }
        java.util.Arrays.sort(files, new java.util.Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return Long.compare(a.lastModified(), b.lastModified());
            }
        });
        for (File file : files) {
            if (total <= 48L * 1024 * 1024) {
                break;
            }
            total -= file.length();
            file.delete();
        }
    }

    private static synchronized LruCache<String, Bitmap> cache() {
        if (cache == null) {
            int maxKb = (int) (Runtime.getRuntime().maxMemory() / 1024 / 8);
            cache = new LruCache<String, Bitmap>(maxKb) {
                @Override
                protected int sizeOf(String key, Bitmap value) {
                    return value.getByteCount() / 1024;
                }
            };
        }
        return cache;
    }

    public static void clearMemory() {
        cache().evictAll();
    }

    public static void clearDisk(Context context) {
        File dir = diskDir(context);
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                file.delete();
            }
        }
    }

    public static long diskSize(Context context) {
        File[] files = diskDir(context).listFiles();
        if (files == null) {
            return 0;
        }
        long size = 0;
        for (File file : files) {
            size += file.length();
        }
        return size;
    }

    private static File diskDir(Context context) {
        File dir = new File(context.getCacheDir(), "art_cache");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    private static File diskFile(Context context, String key) {
        return new File(diskDir(context), Integer.toHexString(key.hashCode()) + ".jpg");
    }

    public static void load(Context context, String uri, int size, Callback callback) {
        load(context, null, uri, size, callback);
    }

    /** customKey 存在时优先使用用户自定义封面/头像。 */
    public static void load(Context context, final String customKey, final String uri,
                            final int size, final Callback callback) {
        if (uri == null) {
            return;
        }
        final String key = (customKey == null ? "" : customKey + "@") + uri + "#" + size;
        Bitmap cached = cache().get(key);
        if (cached != null) {
            callback.onArt(uri, cached);
            return;
        }
        final Context app = context.getApplicationContext();
        EXECUTOR.execute(new Runnable() {
            @Override
            public void run() {
                Bitmap bitmap = customKey == null ? null : CustomArtStore.load(app, customKey, size);
                if (bitmap == null) {
                    File disk = diskFile(app, key);
                    if (disk.exists()) {
                        bitmap = decodeFile(disk, size);
                    }
                    if (bitmap == null) {
                        bitmap = Art.load(app, uri, size);
                        if (bitmap != null) {
                            saveFile(disk, bitmap);
                        }
                    }
                }
                if (bitmap != null) {
                    cache().put(key, bitmap);
                }
                final Bitmap result = bitmap;
                MAIN.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onArt(uri, result);
                    }
                });
            }
        });
    }
}
