package com.flatplayer.neo;

import android.widget.AbsListView;
import android.widget.ListView;

/** 列表滑动时暂停昂贵操作（音质元数据读取），停下后恢复。 */
public final class ScrollPause {

    public interface Pausable {
        void setScrolling(boolean scrolling);
    }

    private ScrollPause() {
    }

    public static void attach(ListView list, final Pausable pausable) {
        if (list == null || pausable == null) {
            return;
        }
        list.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                boolean scrolling = scrollState != AbsListView.OnScrollListener.SCROLL_STATE_IDLE;
                pausable.setScrolling(scrolling);
                if (!scrolling) {
                    view.post(new Runnable() {
                        @Override
                        public void run() {
                            // 停下后重新绑定可见行
                            if (view.getAdapter() != null) {
                                ((android.widget.BaseAdapter) view.getAdapter()).notifyDataSetChanged();
                            }
                        }
                    });
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem,
                                 int visibleItemCount, int totalItemCount) {
            }
        });
    }
}
