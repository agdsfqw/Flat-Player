package com.flatplayer.neo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 文件夹管理：媒体库目录 + SAF 任意目录，勾选后进入音乐库。 */
public class FolderActivity extends BaseActivity {

    private static final int REQ_TREE = 21;

    private final ArrayList<Row> rows = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();
    private Prefs prefs;
    private ListView list;
    private TextView empty;
    private TextView scanStatus;
    private ProgressBar scanProgress;
    private TextView scanCancel;
    private TextView scanNow;
    private FolderAdapter adapter;

    static class Row {
        String key;
        String name;
        String path;
        int count;
        boolean saf;
        String rootUri;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_folder);
        prefs = new Prefs(this);
        selected.addAll(prefs.selectedFolders());
        list = findViewById(R.id.folder_list);
        empty = findViewById(R.id.folder_empty);
        scanStatus = findViewById(R.id.scan_status);
        scanProgress = findViewById(R.id.scan_progress);
        scanCancel = findViewById(R.id.scan_cancel);
        scanNow = findViewById(R.id.scan_now);
        adapter = new FolderAdapter();
        list.setAdapter(adapter);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.add_dir).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickDirectory();
            }
        });
        scanNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startScan();
            }
        });
        scanCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SafScanner.cancel();
            }
        });
        findViewById(R.id.select_all).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selected.clear();
                for (Row row : rows) {
                    selected.add(row.key);
                }
                prefs.setSelectedFolders(selected);
                adapter.notifyDataSetChanged();
            }
        });
        findViewById(R.id.select_none).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selected.clear();
                prefs.setSelectedFolders(selected);
                adapter.notifyDataSetChanged();
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Row row = rows.get(position);
                if (selected.contains(row.key)) {
                    selected.remove(row.key);
                } else {
                    selected.add(row.key);
                }
                prefs.setSelectedFolders(selected);
                adapter.notifyDataSetChanged();
            }
        });
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Row row = rows.get(position);
                if (row.saf) {
                    showRootMenu(row);
                    return true;
                }
                return false;
            }
        });

        if (SafScanner.isRunning()) {
            showScan(true, 0);
        }
        load();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!SafScanner.isRunning() && scanProgress.getVisibility() == View.VISIBLE) {
            showScan(false, 0);
            load();
        }
    }

    private void pickDirectory() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQ_TREE);
        } catch (Exception e) {
            Toast.makeText(this, "系统不支持目录选择", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_TREE || resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // 无法持久化时本次仍可读
        }
        String name = uri.getLastPathSegment();
        try {
            String docId = DocumentsContract.getTreeDocumentId(uri);
            int colon = docId.indexOf(':');
            if (colon >= 0 && colon < docId.length() - 1) {
                name = docId.substring(colon + 1);
            }
        } catch (Exception ignored) {
            // 使用 lastPathSegment
        }
        if (name == null || name.isEmpty()) {
            name = "外部目录";
        }
        ArrayList<SafStore.Root> roots = SafStore.roots(this);
        for (SafStore.Root root : roots) {
            if (root.uri.equals(uri.toString())) {
                Toast.makeText(this, "该目录已添加", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        roots.add(new SafStore.Root(uri.toString(), name));
        SafStore.setRoots(this, roots);
        String key = "saf:" + uri;
        if (prefs.foldersConfigured()) {
            selected.add(key);
            prefs.setSelectedFolders(selected);
        }
        startScan();
    }

    private void startScan() {
        if (SafScanner.isRunning()) {
            return;
        }
        showScan(true, 0);
        SafScanner.start(this, new SafScanner.Listener() {
            @Override
            public void onProgress(final int count, String name) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing()) {
                            showScan(true, count);
                        }
                    }
                });
            }

            @Override
            public void onDone(final int count) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing()) {
                            return;
                        }
                        showScan(false, count);
                        Toast.makeText(FolderActivity.this,
                                getString(R.string.scan_finished, count), Toast.LENGTH_LONG).show();
                        load();
                    }
                });
            }

            @Override
            public void onError(final String message) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing()) {
                            return;
                        }
                        showScan(false, 0);
                        Toast.makeText(FolderActivity.this, message, Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
    }

    private void showScan(boolean running, int count) {
        scanStatus.setVisibility(running ? View.VISIBLE : View.GONE);
        scanProgress.setVisibility(running ? View.VISIBLE : View.GONE);
        scanCancel.setVisibility(running ? View.VISIBLE : View.GONE);
        scanNow.setVisibility(!running && !SafStore.roots(this).isEmpty()
                ? View.VISIBLE : View.GONE);
        if (running) {
            scanStatus.setText(getString(R.string.scanning, count));
        }
    }

    private void showRootMenu(final Row row) {
        String[] items = {getString(R.string.rescan_full), getString(R.string.remove_folder)};
        new AlertDialog.Builder(this)
                .setTitle(row.name)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            fullRescan();
                        } else {
                            confirmRemove(row);
                        }
                    }
                })
                .show();
    }

    private void fullRescan() {
        if (SafScanner.isRunning()) {
            return;
        }
        showScan(true, 0);
        SafScanner.start(this, new SafScanner.Listener() {
            @Override
            public void onProgress(final int count, String name) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing()) {
                            showScan(true, count);
                        }
                    }
                });
            }

            @Override
            public void onDone(final int count) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing()) {
                            showScan(false, 0);
                            load();
                            Toast.makeText(FolderActivity.this,
                                    getString(R.string.scan_finished, count), Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }

            @Override
            public void onError(final String message) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing()) {
                            showScan(false, 0);
                            Toast.makeText(FolderActivity.this, message, Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        }, true);
    }

    private void confirmRemove(final Row row) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.remove_folder)
                .setMessage(R.string.remove_folder_msg)
                .setPositiveButton(R.string.remove, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        removeRoot(row);
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void removeRoot(Row row) {
        ArrayList<SafStore.Root> roots = SafStore.roots(this);
        ArrayList<SafStore.Root> kept = new ArrayList<>();
        for (SafStore.Root root : roots) {
            if (!("saf:" + root.uri).equals(row.key)) {
                kept.add(root);
            }
        }
        SafStore.setRoots(this, kept);

        ArrayList<Track> tracks = SafStore.tracks(this);
        ArrayList<Track> keptTracks = new ArrayList<>();
        for (Track track : tracks) {
            if (!row.key.equals(track.bucketKey)) {
                keptTracks.add(track);
            }
        }
        SafStore.setTracks(this, keptTracks);

        selected.remove(row.key);
        prefs.setSelectedFolders(selected);
        load();
    }

    private void load() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<Track> all = Library.loadAll(FolderActivity.this);
                Map<String, Row> map = new LinkedHashMap<>();
                for (Track track : all) {
                    Row row = map.get(track.bucketKey);
                    if (row == null) {
                        row = new Row();
                        row.key = track.bucketKey;
                        row.name = track.bucketName;
                        row.path = track.relativePath == null ? "" : track.relativePath;
                        row.saf = track.bucketKey.startsWith("saf:");
                        row.rootUri = row.saf ? track.bucketKey.substring(4) : null;
                        map.put(track.bucketKey, row);
                    }
                    row.count++;
                }
                for (SafStore.Root root : SafStore.roots(FolderActivity.this)) {
                    String key = "saf:" + root.uri;
                    Row row = map.get(key);
                    if (row == null) {
                        row = new Row();
                        row.key = key;
                        row.name = root.name;
                        row.path = "";
                        row.saf = true;
                        row.rootUri = root.uri;
                        map.put(key, row);
                    }
                }
                final ArrayList<Row> result = new ArrayList<>(map.values());
                java.util.Collections.sort(result, new java.util.Comparator<Row>() {
                    @Override
                    public int compare(Row a, Row b) {
                        if (a.saf != b.saf) {
                            return a.saf ? -1 : 1;
                        }
                        return a.name.compareToIgnoreCase(b.name);
                    }
                });
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        rows.clear();
                        rows.addAll(result);
                        if (selected.isEmpty() && !prefs.foldersConfigured() && !rows.isEmpty()) {
                            for (Row row : rows) {
                                selected.add(row.key);
                            }
                            prefs.setSelectedFolders(selected);
                        }
                        adapter.notifyDataSetChanged();
                        empty.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
                        if (!SafScanner.isRunning()) {
                            showScan(false, 0);
                        }
                    }
                });
            }
        }).start();
    }

    private class FolderAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public Row getItem(int position) {
            return rows.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = getLayoutInflater().inflate(R.layout.item_folder, parent, false);
            }
            Row row = rows.get(position);
            TextView name = view.findViewById(R.id.f_name);
            TextView path = view.findViewById(R.id.f_path);
            TextView count = view.findViewById(R.id.f_count);
            CheckBox check = view.findViewById(R.id.f_check);
            name.setText(row.saf ? row.name + "（外部）" : row.name);
            path.setText(row.path);
            count.setText(row.count + " 首");
            check.setChecked(!selected.isEmpty() && selected.contains(row.key));
            return view;
        }
    }
}
