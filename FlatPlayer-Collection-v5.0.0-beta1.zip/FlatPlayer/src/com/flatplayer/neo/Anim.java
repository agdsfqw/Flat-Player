package com.flatplayer.neo;

import android.content.Context;

/** 全应用动画时长策略：0 表示直接落到终态。 */
public final class Anim {

    private Anim() {
    }

    public static boolean enabled(Context context) {
        return duration(context, 100) > 0;
    }

    public static int duration(Context context, int base) {
        Prefs prefs = new Prefs(context.getApplicationContext());
        if (prefs.reduceMotion()) {
            return 0;
        }
        switch (prefs.animationLevel()) {
            case 0:
                return 0;
            case 1:
                return Math.max(40, base / 2);
            case 3:
                return base * 3 / 2;
            default:
                return base;
        }
    }
}
