package com.flatplayer.neo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class ArtistDetailActivity extends PlayerBindActivity {

    public static final String EXTRA_ARTIST = "artist";

    private static final int REQ_PICK = 33;
    private static final int REQ_CROP = 34;

    private final ArrayList<Track> tracks = new ArrayList<>();
    private SimpleTrackAdapter adapter;
    private String artistName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artist);

        final String artist = getIntent().getStringExtra(EXTRA_ARTIST);
        artistName = artist;
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ListView list = findViewById(R.id.d_list);
        adapter = new SimpleTrackAdapter(this);
        list.setAdapter(adapter);
        ScrollPause.attach(list, adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                playQueue(tracks, position);
            }
        });
        findViewById(R.id.play_all).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playQueue(tracks, 0);
            }
        });
        findViewById(R.id.d_avatar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAvatarMenu();
            }
        });

        new Thread(new Runnable() {
            @Override
            public void run() {
                final ArrayList<Track> result = new ArrayList<>();
                for (Track track : Library.load(ArtistDetailActivity.this)) {
                    if (artist != null && artist.equals(track.artist)) {
                        result.add(track);
                    }
                }
                SortUtil.sort(result, new Prefs(ArtistDetailActivity.this).sortMode(), ArtistDetailActivity.this);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tracks.clear();
                        tracks.addAll(result);
                        adapter.setTracks(tracks);
                        bindHeader(artist);
                    }
                });
            }
        }).start();
    }

    private void showAvatarMenu() {
        final String key = CustomArtStore.artistKey(artistName);
        if (key == null) {
            return;
        }
        String[] items = {getString(R.string.change_avatar), getString(R.string.restore_default_avatar)};
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.change_avatar)
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface dialog, int which) {
                        if (which == 0) {
                            pickImage();
                        } else {
                            CustomArtStore.clear(ArtistDetailActivity.this, key);
                            ArtLoader.clearMemory();
                            recreate();
                        }
                    }
                })
                .show();
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        try {
            startActivityForResult(intent, REQ_PICK);
        } catch (Exception e) {
            android.widget.Toast.makeText(this, "无法打开图片选择器", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) {
            return;
        }
        if (requestCode == REQ_PICK && data != null && data.getData() != null) {
            Intent crop = new Intent(this, CropActivity.class);
            crop.putExtra(CropActivity.EXTRA_IMAGE, data.getData().toString());
            crop.putExtra(CropActivity.EXTRA_KEY, CustomArtStore.artistKey(artistName));
            startActivityForResult(crop, REQ_CROP);
        } else if (requestCode == REQ_CROP) {
            recreate();
        }
    }

    private void bindHeader(String artist) {
        TextView name = findViewById(R.id.d_name);
        TextView meta = findViewById(R.id.d_meta);
        name.setText(artist == null ? getString(R.string.unknown_artist) : artist);

        Set<Long> albumIds = new HashSet<>();
        for (Track track : tracks) {
            albumIds.add(track.albumId);
        }
        meta.setText(tracks.size() + " 首 · " + albumIds.size() + " 张专辑");

        if (!tracks.isEmpty()) {
            final ImageView avatar = findViewById(R.id.d_avatar);
            final TextView tile = findViewById(R.id.d_tile);
            Tiles.apply(tile, artist, true);
            final String uri = tracks.get(0).uri;
            avatar.setTag(uri);
            ArtLoader.load(this, CustomArtStore.artistKey(artist), uri, 512, new ArtLoader.Callback() {
                @Override
                public void onArt(String u, Bitmap bitmap) {
                    if (bitmap != null && uri.equals(avatar.getTag())) {
                        avatar.setImageBitmap(bitmap);
                        tile.setVisibility(View.GONE);
                    }
                }
            });
        }
    }
}
