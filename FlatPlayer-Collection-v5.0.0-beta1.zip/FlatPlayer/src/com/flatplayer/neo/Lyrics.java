package com.flatplayer.neo;

import android.content.Context;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 歌词加载：同名 .lrc（SAF）→ 内嵌（MP3 ID3v2 USLT/SYLT、FLAC/OGG Vorbis、M4A ©lyr）。
 * 解析失败一律降级为「无歌词」，绝不抛异常。
 */
public final class Lyrics {

    public static class Line {
        public final long time;
        public final String text;

        Line(long time, String text) {
            this.time = time;
            this.text = text;
        }
    }

    public static class Data {
        public final boolean timed;
        public final List<Line> lines;
        public final String plain;

        Data(boolean timed, List<Line> lines, String plain) {
            this.timed = timed;
            this.lines = lines;
            this.plain = plain;
        }

        public static Data empty() {
            return new Data(false, new ArrayList<Line>(), "");
        }
    }

    private static final Pattern TIME_TAG = Pattern.compile("\\[(\\d{1,3}):(\\d{1,2})(?:[.:](\\d{1,3}))?\\]");
    private static final Pattern OFFSET_TAG = Pattern.compile("\\[offset:([+-]?\\d+)\\]", Pattern.CASE_INSENSITIVE);

    private Lyrics() {
    }

    public static Data load(Context context, Track track) {
        if (track == null) {
            return Data.empty();
        }
        try {
            if (track.lyricUri != null && !track.lyricUri.isEmpty()) {
                byte[] data = readUri(context, Uri.parse(track.lyricUri), 2 * 1024 * 1024);
                Data parsed = parse(decode(data));
                if (parsed != null) {
                    return parsed;
                }
            }
            byte[] audio = readAudioHead(context, track, 8 * 1024 * 1024);
            if (audio != null) {
                String text = extractEmbedded(audio, track.displayName);
                Data parsed = parse(text);
                if (parsed != null) {
                    return parsed;
                }
            }
        } catch (Throwable ignored) {
            // 降级为无歌词
        }
        return Data.empty();
    }

    // ------------------------------------------------------------------ LRC

    public static Data parse(String text) {
        if (text == null) {
            return null;
        }
        String content = text.replace("\r\n", "\n").replace('\r', '\n').trim();
        if (content.isEmpty()) {
            return null;
        }
        long offset = 0;
        Matcher offsetMatcher = OFFSET_TAG.matcher(content);
        if (offsetMatcher.find()) {
            try {
                offset = Long.parseLong(offsetMatcher.group(1));
            } catch (NumberFormatException ignored) {
                offset = 0;
            }
        }
        ArrayList<Line> lines = new ArrayList<>();
        for (String raw : content.split("\n")) {
            String line = raw.trim();
            if (line.isEmpty()) {
                continue;
            }
            Matcher matcher = TIME_TAG.matcher(line);
            ArrayList<Long> times = new ArrayList<>();
            int lastEnd = -1;
            while (matcher.find()) {
                long minute = Long.parseLong(matcher.group(1));
                long second = Long.parseLong(matcher.group(2));
                long fraction = 0;
                String frac = matcher.group(3);
                if (frac != null) {
                    if (frac.length() == 1) {
                        fraction = Long.parseLong(frac) * 100;
                    } else if (frac.length() == 2) {
                        fraction = Long.parseLong(frac) * 10;
                    } else {
                        fraction = Long.parseLong(frac);
                    }
                }
                times.add(minute * 60000 + second * 1000 + fraction);
                lastEnd = matcher.end();
            }
            if (times.isEmpty()) {
                continue;
            }
            String lyric = line.substring(lastEnd).trim();
            for (long time : times) {
                lines.add(new Line(Math.max(0, time + offset), lyric));
            }
        }
        if (lines.isEmpty()) {
            return new Data(false, new ArrayList<Line>(), content);
        }
        Collections.sort(lines, new Comparator<Line>() {
            @Override
            public int compare(Line a, Line b) {
                return Long.compare(a.time, b.time);
            }
        });
        return new Data(true, lines, content);
    }

    // ------------------------------------------------------------ 内嵌歌词

    private static String extractEmbedded(byte[] data, String name) {
        String lower = name == null ? "" : name.toLowerCase(Locale.ROOT);
        try {
            if (lower.endsWith(".mp3") || (data.length > 3 && data[0] == 'I' && data[1] == 'D' && data[2] == '3')) {
                String text = parseId3(data);
                if (text != null && !text.trim().isEmpty()) {
                    return text;
                }
            }
            if (lower.endsWith(".flac") || startsWith(data, "fLaC")) {
                String text = parseFlac(data);
                if (text != null && !text.trim().isEmpty()) {
                    return text;
                }
            }
            if (lower.endsWith(".m4a") || lower.endsWith(".mp4")) {
                String text = parseMp4(data);
                if (text != null && !text.trim().isEmpty()) {
                    return text;
                }
            }
            String text = scanVorbisComment(data);
            if (text != null && !text.trim().isEmpty()) {
                return text;
            }
        } catch (Throwable ignored) {
            // 解析失败
        }
        return null;
    }

    private static String parseId3(byte[] b) {
        if (b.length < 10 || b[0] != 'I' || b[1] != 'D' || b[2] != '3') {
            return null;
        }
        int version = b[3] & 0xff;
        int flags = b[5] & 0xff;
        int size = synchsafe(b, 6);
        int end = Math.min(b.length, 10 + size);
        int pos = 10;
        if ((flags & 0x40) != 0) {
            pos += 4; // extended header
        }
        String best = null;
        while (pos + 10 <= end) {
            String id;
            int frameSize;
            int headerSize;
            if (version == 2) {
                id = new String(b, pos, 3, StandardCharsets.ISO_8859_1);
                frameSize = ((b[pos + 3] & 0xff) << 16) | ((b[pos + 4] & 0xff) << 8) | (b[pos + 5] & 0xff);
                headerSize = 6;
            } else {
                id = new String(b, pos, 4, StandardCharsets.ISO_8859_1);
                frameSize = version == 4 ? synchsafe(b, pos + 4) : bigEndian(b, pos + 4);
                headerSize = 10;
            }
            if (id.trim().isEmpty() || frameSize <= 0 || pos + headerSize + frameSize > b.length) {
                break;
            }
            if ("USLT".equals(id) || "ULT".equals(id)) {
                String text = parseUslt(b, pos + headerSize, frameSize);
                if (text != null && !text.trim().isEmpty()) {
                    best = text;
                }
            } else if ("SYLT".equals(id) || "SLT".equals(id)) {
                String text = parseSylt(b, pos + headerSize, frameSize);
                if (text != null && !text.trim().isEmpty()) {
                    best = text;
                }
            }
            pos += headerSize + frameSize;
        }
        return best;
    }

    private static String parseUslt(byte[] b, int offset, int size) {
        if (size < 4) {
            return null;
        }
        int encoding = b[offset] & 0xff;
        offset += 4; // encoding + language
        int end = Math.min(b.length, offset + size - 4);
        int textStart = offset;
        while (textStart + 1 < end) {
            if (b[textStart] == 0 && (encoding == 1 || encoding == 2 ? b[textStart + 1] == 0 : true)) {
                textStart += (encoding == 1 || encoding == 2 ? 2 : 1);
                break;
            }
            textStart++;
        }
        return decodeRange(b, textStart, end, encoding);
    }

    private static String parseSylt(byte[] b, int offset, int size) {
        if (size < 6) {
            return null;
        }
        int encoding = b[offset] & 0xff;
        int pos = offset + 6; // encoding + language + timestamp format + content type
        int end = Math.min(b.length, offset + size);
        int start = pos;
        while (pos + 1 < end) {
            if (b[pos] == 0 && (encoding == 1 || encoding == 2 ? b[pos + 1] == 0 : true)) {
                pos += (encoding == 1 || encoding == 2 ? 2 : 1);
                break;
            }
            pos++;
        }
        StringBuilder sb = new StringBuilder();
        while (pos + 4 <= end) {
            int textStart = pos;
            while (pos + 1 < end) {
                if (b[pos] == 0 && (encoding == 1 || encoding == 2 ? b[pos + 1] == 0 : true)) {
                    break;
                }
                pos++;
            }
            String text = decodeRange(b, textStart, pos, encoding);
            pos += (encoding == 1 || encoding == 2 ? 2 : 1);
            if (pos + 4 > end) {
                break;
            }
            long time = bigEndian(b, pos);
            pos += 4;
            sb.append(formatTime(time)).append(text).append('\n');
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    private static String parseFlac(byte[] b) {
        if (!startsWith(b, "fLaC")) {
            return null;
        }
        int pos = 4;
        while (pos + 4 <= b.length) {
            int header = b[pos] & 0xff;
            boolean last = (header & 0x80) != 0;
            int type = header & 0x7f;
            int length = ((b[pos + 1] & 0xff) << 16) | ((b[pos + 2] & 0xff) << 8) | (b[pos + 3] & 0xff);
            pos += 4;
            if (type == 4 && pos + length <= b.length) {
                String text = readVorbisComment(b, pos, length);
                if (text != null && !text.isEmpty()) {
                    return text;
                }
            }
            pos += length;
            if (last) {
                break;
            }
        }
        return null;
    }

    private static String readVorbisComment(byte[] b, int offset, int length) {
        try {
            int pos = offset;
            int vendorLength = littleEndian(b, pos);
            pos += 4 + vendorLength;
            if (pos + 4 > offset + length) {
                return null;
            }
            int count = littleEndian(b, pos);
            pos += 4;
            for (int i = 0; i < count && pos + 4 <= offset + length; i++) {
                int itemLength = littleEndian(b, pos);
                pos += 4;
                if (itemLength <= 0 || pos + itemLength > offset + length) {
                    break;
                }
                String item = new String(b, pos, itemLength, StandardCharsets.UTF_8);
                pos += itemLength;
                int eq = item.indexOf('=');
                if (eq > 0) {
                    String key = item.substring(0, eq).toUpperCase(Locale.ROOT);
                    if ("LYRICS".equals(key) || "UNSYNCEDLYRICS".equals(key) || "UNSYNCED LYRICS".equals(key)) {
                        return item.substring(eq + 1);
                    }
                }
            }
        } catch (Throwable ignored) {
            // 忽略
        }
        return null;
    }

    private static String scanVorbisComment(byte[] b) {
        byte[] key = "LYRICS=".getBytes(StandardCharsets.US_ASCII);
        int index = indexOf(b, key);
        if (index < 0) {
            key = "UNSYNCEDLYRICS=".getBytes(StandardCharsets.US_ASCII);
            index = indexOf(b, key);
        }
        if (index < 0) {
            return null;
        }
        int start = index + key.length;
        int end = start;
        while (end < b.length && b[end] != 0 && end - start < 65536) {
            end++;
        }
        return new String(b, start, end - start, StandardCharsets.UTF_8);
    }

    private static String parseMp4(byte[] b) {
        byte[] key = {0, 0, 0, 0, (byte) 0xA9, 'l', 'y', 'r'};
        int index = -1;
        for (int i = 0; i + 8 <= b.length; i++) {
            if ((b[i + 4] & 0xff) == 0xA9 && b[i + 5] == 'l' && b[i + 6] == 'y' && b[i + 7] == 'r') {
                index = i;
                break;
            }
        }
        if (index < 0) {
            return null;
        }
        int size = bigEndian(b, index);
        int end = Math.min(b.length, index + size);
        int dataPos = index + 8;
        while (dataPos + 8 <= end) {
            int atomSize = bigEndian(b, dataPos);
            if (atomSize <= 0 || dataPos + atomSize > end) {
                break;
            }
            if (b[dataPos + 4] == 'd' && b[dataPos + 5] == 'a' && b[dataPos + 6] == 't' && b[dataPos + 7] == 'a') {
                int textStart = dataPos + 16;
                if (textStart < dataPos + atomSize) {
                    return new String(b, textStart, dataPos + atomSize - textStart, StandardCharsets.UTF_8).trim();
                }
            }
            dataPos += atomSize;
        }
        return null;
    }

    // ------------------------------------------------------------------ 工具

    private static Data decodeAndParse(byte[] data) {
        return parse(decode(data));
    }

    private static String decode(byte[] data) {
        if (data == null || data.length == 0) {
            return null;
        }
        if (data.length > 3 && (data[0] & 0xff) == 0xEF && (data[1] & 0xff) == 0xBB && (data[2] & 0xff) == 0xBF) {
            return new String(data, 3, data.length - 3, StandardCharsets.UTF_8);
        }
        if (data.length > 2 && (data[0] & 0xff) == 0xFF && (data[1] & 0xff) == 0xFE) {
            return new String(data, 2, data.length - 2, StandardCharsets.UTF_16LE);
        }
        if (data.length > 2 && (data[0] & 0xff) == 0xFE && (data[1] & 0xff) == 0xFF) {
            return new String(data, 2, data.length - 2, StandardCharsets.UTF_16BE);
        }
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(data)).toString();
        } catch (CharacterCodingException e) {
            try {
                return Charset.forName("GBK").decode(ByteBuffer.wrap(data)).toString();
            } catch (Throwable ignored) {
                return new String(data, StandardCharsets.ISO_8859_1);
            }
        }
    }

    private static String decodeRange(byte[] b, int start, int end, int encoding) {
        if (start >= end) {
            return null;
        }
        int length = end - start;
        try {
            switch (encoding) {
                case 1:
                    return new String(b, start, length, StandardCharsets.UTF_16);
                case 2:
                    return new String(b, start, length, StandardCharsets.UTF_16BE);
                case 3:
                    return new String(b, start, length, StandardCharsets.UTF_8);
                default:
                    return new String(b, start, length, StandardCharsets.ISO_8859_1);
            }
        } catch (Throwable t) {
            return null;
        }
    }

    private static byte[] readAudioHead(Context context, Track track, int limit) {
        return readUri(context, Uri.parse(track.uri), limit);
    }

    private static byte[] readUri(Context context, Uri uri, int limit) {
        InputStream in = null;
        try {
            in = context.getContentResolver().openInputStream(uri);
            if (in == null) {
                return null;
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int read;
            int total = 0;
            while ((read = in.read(buffer)) > 0 && total < limit) {
                out.write(buffer, 0, read);
                total += read;
            }
            return out.toByteArray();
        } catch (Throwable t) {
            return null;
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception ignored) {
                    // 忽略
                }
            }
        }
    }

    private static boolean startsWith(byte[] b, String text) {
        if (b.length < text.length()) {
            return false;
        }
        for (int i = 0; i < text.length(); i++) {
            if (b[i] != (byte) text.charAt(i)) {
                return false;
            }
        }
        return true;
    }

    private static int indexOf(byte[] data, byte[] key) {
        outer:
        for (int i = 0; i + key.length <= data.length; i++) {
            for (int j = 0; j < key.length; j++) {
                if (data[i + j] != key[j]) {
                    continue outer;
                }
            }
            return i;
        }
        return -1;
    }

    private static int synchsafe(byte[] b, int offset) {
        return ((b[offset] & 0x7f) << 21) | ((b[offset + 1] & 0x7f) << 14)
                | ((b[offset + 2] & 0x7f) << 7) | (b[offset + 3] & 0x7f);
    }

    private static int bigEndian(byte[] b, int offset) {
        return ((b[offset] & 0xff) << 24) | ((b[offset + 1] & 0xff) << 16)
                | ((b[offset + 2] & 0xff) << 8) | (b[offset + 3] & 0xff);
    }

    private static int littleEndian(byte[] b, int offset) {
        return (b[offset] & 0xff) | ((b[offset + 1] & 0xff) << 8)
                | ((b[offset + 2] & 0xff) << 16) | ((b[offset + 3] & 0xff) << 24);
    }

    private static String formatTime(long ms) {
        long total = ms / 1000;
        return String.format("[%02d:%02d]", total / 60, total % 60);
    }
}
