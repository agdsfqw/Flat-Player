package com.flatplayer.neo;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import java.io.File;
import java.util.ArrayList;
import java.util.Set;

public final class Library {

    private Library() {
    }

    /** 应用「隐藏歌曲」与「勾选文件夹」之后的曲库。 */
    public static ArrayList<Track> load(Context context) {
        ArrayList<Track> all = loadAll(context);
        Prefs prefs = new Prefs(context);
        Set<String> hidden = prefs.hiddenTracks();
        Set<String> folders = prefs.selectedFolders();
        ArrayList<Track> out = new ArrayList<>();
        for (Track track : all) {
            if (hidden.contains(track.uri)) {
                continue;
            }
            if (prefs.foldersConfigured() && !folders.contains(track.bucketKey)) {
                continue;
            }
            out.add(track);
        }
        return out;
    }

    /** 未过滤的原始音频列表，供文件夹页与隐藏页使用。 */
    public static ArrayList<Track> loadAll(Context context) {
        Prefs prefs = new Prefs(context);
        ArrayList<Track> out = new ArrayList<>();
        if (!prefs.safOnly()) {
            String duration = MediaStore.Audio.Media.DURATION + " >= 30000";
            out = query(context, MediaStore.Audio.Media.IS_MUSIC + " != 0 AND " + duration);
            if (out.isEmpty()) {
                out = query(context, MediaStore.Audio.Media.MIME_TYPE + " LIKE 'audio/%' AND " + duration);
            }
        }
        ArrayList<Track> saf = SafStore.tracks(context);
        if (!saf.isEmpty()) {
            Set<String> keys = new java.util.HashSet<>();
            for (Track track : out) {
                keys.add(dedupeKey(track));
            }
            for (Track track : saf) {
                if (!keys.contains(dedupeKey(track))) {
                    out.add(track);
                }
            }
        }
        return applyOverrides(context, out);
    }

    /** 标签编辑后立即在应用内生效，不必等系统媒体库重扫。 */
    private static ArrayList<Track> applyOverrides(Context context, ArrayList<Track> list) {
        org.json.JSONObject overrides = new Prefs(context).metaOverrides();
        if (overrides.length() == 0) {
            return list;
        }
        ArrayList<Track> out = new ArrayList<>();
        for (Track track : list) {
            org.json.JSONObject item = overrides.optJSONObject(track.uri);
            if (item == null) {
                out.add(track);
                continue;
            }
            out.add(new Track(track.id, track.uri,
                    item.optString("title", track.title),
                    item.optString("artist", track.artist),
                    item.optString("album", track.album),
                    track.albumId, track.duration, track.displayName, track.relativePath,
                    track.bucketKey, track.bucketName, track.year, track.dateAdded,
                    track.lyricUri));
        }
        return out;
    }

    private static String dedupeKey(Track track) {
        String name = track.displayName == null || track.displayName.isEmpty()
                ? track.title : track.displayName;
        return (name + "|" + track.duration).toLowerCase();
    }

    private static ArrayList<Track> query(Context context, String selection) {
        ArrayList<Track> out = new ArrayList<>();
        boolean modern = Build.VERSION.SDK_INT >= 29;
        String[] projection = {
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.ALBUM_ID,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.MIME_TYPE,
                modern ? MediaStore.Audio.Media.RELATIVE_PATH : MediaStore.Audio.Media.DATA,
                modern ? MediaStore.Audio.Media.BUCKET_ID : MediaStore.Audio.Media.DATA,
                modern ? MediaStore.Audio.Media.BUCKET_DISPLAY_NAME : MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.YEAR,
                MediaStore.Audio.Media.DATE_ADDED
        };

        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    projection, selection, null,
                    MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC");
            if (cursor == null) {
                return out;
            }
            int idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
            int titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
            int artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
            int albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM);
            int albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID);
            int durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);
            int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME);
            int pathCol = 8;
            int bucketIdCol = 9;
            int bucketNameCol = 10;
            int yearCol = 11;
            int addedCol = 12;

            while (cursor.moveToNext()) {
                long id = cursor.getLong(idCol);
                String title = cursor.getString(titleCol);
                String artist = cursor.getString(artistCol);
                if (title == null || title.trim().isEmpty()) {
                    title = context.getString(R.string.unnamed);
                }
                if (artist == null || artist.trim().isEmpty() || "<unknown>".equals(artist)) {
                    artist = context.getString(R.string.unknown_artist);
                }
                String bucketKey;
                String bucketName;
                String relativePath;
                if (modern) {
                    long bucketId = cursor.getLong(bucketIdCol);
                    bucketName = cursor.getString(bucketNameCol);
                    bucketKey = "id:" + bucketId;
                    relativePath = cursor.getString(pathCol);
                } else {
                    String data = cursor.getString(pathCol);
                    File file = data == null ? null : new File(data);
                    File parent = file == null ? null : file.getParentFile();
                    bucketName = parent == null ? context.getString(R.string.unknown_folder) : parent.getName();
                    bucketKey = "path:" + (parent == null ? "" : parent.getAbsolutePath());
                    relativePath = parent == null ? "" : parent.getAbsolutePath();
                }
                if (bucketName == null || bucketName.trim().isEmpty()) {
                    bucketName = context.getString(R.string.unknown_folder);
                }
                Uri uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
                out.add(new Track(
                        id,
                        uri.toString(),
                        title,
                        artist,
                        cursor.getString(albumCol),
                        cursor.getLong(albumIdCol),
                        cursor.getLong(durCol),
                        cursor.getString(nameCol),
                        relativePath,
                        bucketKey,
                        bucketName,
                        cursor.getInt(yearCol),
                        cursor.getLong(addedCol),
                        ""));
            }
        } catch (Exception ignored) {
            // 权限被收回或媒体库不可用时返回已读到的部分
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return out;
    }
}
