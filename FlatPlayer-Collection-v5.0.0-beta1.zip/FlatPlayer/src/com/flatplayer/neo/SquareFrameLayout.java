package com.flatplayer.neo;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/** 宽度决定高度的正方形容器，避免封面被拉成奇怪的比例。 */
public class SquareFrameLayout extends FrameLayout {

    public SquareFrameLayout(Context context) {
        super(context);
    }

    public SquareFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SquareFrameLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec);
        int height = MeasureSpec.getSize(heightSpec);
        int mode = MeasureSpec.getMode(heightSpec);
        int size = mode == MeasureSpec.UNSPECIFIED ? width : Math.min(width, height);
        super.onMeasure(
                MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY));
    }
}
