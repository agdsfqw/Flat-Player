package com.flatplayer.neo;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/** 均衡器：预设 + 自定义频段。 */
public class EqualizerActivity extends PlayerBindActivity {

    private LinearLayout list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_category);
        ((TextView) findViewById(R.id.category_title)).setText(R.string.equalizer);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        list = findViewById(R.id.category_list);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
    }

    private void build() {
        if (list == null) {
            return;
        }
        list.removeAllViews();
        final String[] names = {
                getString(R.string.eq_off), getString(R.string.eq_pop),
                getString(R.string.eq_rock), getString(R.string.eq_classical),
                getString(R.string.eq_vocal), getString(R.string.eq_bass),
                getString(R.string.eq_custom)
        };
        final int current = service == null ? -1 : service.getEqualizerPreset();
        for (int i = 0; i < names.length; i++) {
            final int index = i;
            final boolean selected = (i == 0 && current < 0)
                    || (i > 0 && i <= 5 && current == i - 1)
                    || (i == 6 && current == 6);
            list.addView(SettingsUi.row(this, (selected ? "✓ " : "") + names[i],
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (service == null) {
                                return;
                            }
                            if (index == 6) {
                                showCustom();
                            } else {
                                service.setEqualizerPreset(index - 1);
                                build();
                            }
                        }
                    }));
        }
    }

    private void showCustom() {
        if (service == null || !service.isEqualizerAvailable()) {
            Toast.makeText(this, R.string.eq_need_play, Toast.LENGTH_SHORT).show();
            return;
        }
        final short count = service.getBandCount();
        final short[] range = service.getBandRange();
        short[] levels = service.getBandLevels();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = SettingsUi.dp(this, 16);
        box.setPadding(pad, pad / 2, pad, pad / 2);
        final SeekBar[] bars = new SeekBar[count];
        for (int i = 0; i < count; i++) {
            TextView label = new TextView(this);
            label.setText("Band " + (i + 1));
            label.setTextSize(11);
            label.setTextColor(SettingsUi.color(this, R.attr.colorTextDim));
            box.addView(label);
            SeekBar bar = new SeekBar(this);
            bar.setMax(range[1] - range[0]);
            bar.setProgress(levels[i] - range[0]);
            bars[i] = bar;
            box.addView(bar);
        }
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.addView(box);
        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.eq_custom)
                .setView(scroll)
                .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        short[] values = new short[bars.length];
                        for (int i = 0; i < bars.length; i++) {
                            values[i] = (short) (bars[i].getProgress() + range[0]);
                        }
                        service.setCustomBands(values);
                        build();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
