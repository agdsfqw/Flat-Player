package com.flatplayer.neo;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.os.Build;
import android.view.DragEvent;
import android.content.res.Resources;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** 播放队列：标注正在播放、自动定位、长按上移/下移/移除。 */
public final class QueueDialog {

    private QueueDialog() {
    }

    public static void show(final Activity activity, final PlayerService service) {
        if (service == null) {
            return;
        }
        final ArrayList<Track> queue = new ArrayList<>(service.getQueue());
        if (queue.isEmpty()) {
            new AlertDialog.Builder(activity)
                    .setMessage(R.string.queue_empty)
                    .setPositiveButton(R.string.close, null)
                    .show();
            return;
        }

        View content = LayoutInflater.from(activity).inflate(R.layout.dialog_queue, null);
        final Dialog dialog = new Dialog(activity);
        dialog.setContentView(content);
        GlassDialogs.styleContent(activity, content);

        final TextView title = content.findViewById(R.id.queue_title);
        final ListView list = content.findViewById(R.id.queue_list);
        final QueueAdapter adapter = new QueueAdapter(activity, queue, service);
        list.setAdapter(adapter);
        updateTitle(title, queue.size());
        list.setSelection(Math.max(0, service.getIndex()));

        final Runnable refresh = new Runnable() {
            @Override
            public void run() {
                queue.clear();
                queue.addAll(service.getQueue());
                if (queue.isEmpty()) {
                    dialog.dismiss();
                    return;
                }
                adapter.notifyDataSetChanged();
                updateTitle(title, queue.size());
                list.setSelection(Math.max(0, service.getIndex()));
            }
        };

        list.setOnDragListener(new View.OnDragListener() {
            @Override
            public boolean onDrag(View v, DragEvent event) {
                if (event.getAction() == DragEvent.ACTION_DROP) {
                    int to = list.pointToPosition((int) event.getX(), (int) event.getY());
                    int from = adapter.getDragFrom();
                    if (from >= 0 && to >= 0 && to != from) {
                        service.move(from, to);
                        refresh.run();
                    }
                    adapter.setDragFrom(-1);
                }
                return true;
            }
        });

        content.findViewById(R.id.queue_clear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(activity)
                        .setMessage(R.string.clear_queue)
                        .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                service.clearQueue();
                                dialog.dismiss();
                            }
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show();
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                service.playAt(position);
                dialog.dismiss();
            }
        });

        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                final String[] items = {
                        activity.getString(R.string.play_now),
                        activity.getString(R.string.play_next),
                        activity.getString(R.string.move_up),
                        activity.getString(R.string.move_down),
                        activity.getString(R.string.remove)
                };
                new AlertDialog.Builder(activity)
                        .setTitle(queue.get(position).title)
                        .setItems(items, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                if (which == 0) {
                                    service.playAt(position);
                                    dialog.dismiss();
                                } else if (which == 1) {
                                    int target = Math.min(position, Math.min(service.getIndex() + 1, queue.size() - 1));
                                    service.move(position, target);
                                    refresh.run();
                                } else if (which == 2) {
                                    service.move(position, position - 1);
                                    refresh.run();
                                } else if (which == 3) {
                                    service.move(position, position + 1);
                                    refresh.run();
                                } else {
                                    service.removeAt(position);
                                    refresh.run();
                                }
                            }
                        })
                        .show();
                return true;
            }
        });

        dialog.show();
        GlassDialogs.apply(activity, dialog);
    }

    private static void updateTitle(TextView title, int count) {
        title.setText(title.getContext().getString(R.string.queue_count, count));
    }

    private static class QueueAdapter extends BaseAdapter {

        private final Activity activity;
        private final List<Track> tracks;
        private final PlayerService service;
        private final int colorText;
        private final int colorAccent;
        private final int colorDim;
        private int dragFrom = -1;

        QueueAdapter(Activity activity, List<Track> tracks, PlayerService service) {
            this.activity = activity;
            this.tracks = tracks;
            this.service = service;
            Resources.Theme theme = activity.getTheme();
            colorText = color(theme, R.attr.colorText);
            colorAccent = color(theme, R.attr.colorAccent);
            colorDim = color(theme, R.attr.colorTextDim);
        }

        private static int color(Resources.Theme theme, int attr) {
            TypedValue value = new TypedValue();
            theme.resolveAttribute(attr, value, true);
            return value.data;
        }

        int getDragFrom() {
            return dragFrom;
        }

        void setDragFrom(int position) {
            dragFrom = position;
        }

        @Override
        public int getCount() {
            return tracks.size();
        }

        @Override
        public Track getItem(int position) {
            return tracks.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = LayoutInflater.from(activity).inflate(R.layout.item_queue, parent, false);
            }
            Track track = tracks.get(position);
            boolean current = position == service.getIndex();
            TextView title = view.findViewById(R.id.q_title);
            TextView dur = view.findViewById(R.id.q_dur);
            TextView tag = view.findViewById(R.id.q_tag);
            title.setText(track.title);
            dur.setText(Track.format(track.duration));
            title.setTextColor(current ? colorAccent : colorText);
            dur.setTextColor(current ? colorAccent : colorDim);
            tag.setVisibility(current ? View.VISIBLE : View.GONE);
            View drag = view.findViewById(R.id.q_drag);
            drag.setTag(position);
            drag.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    dragFrom = (Integer) v.getTag();
                    ClipData data = ClipData.newPlainText("", "");
                    View.DragShadowBuilder shadow = new View.DragShadowBuilder(v);
                    if (Build.VERSION.SDK_INT >= 24) {
                        v.startDragAndDrop(data, shadow, null, 0);
                    } else {
                        v.startDrag(data, shadow, null, 0);
                    }
                    return true;
                }
            });
            return view;
        }
    }
}
