package com.flatplayer.neo;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** 独立搜索页：歌曲、歌手、专辑、搜索历史。 */
public class SearchActivity extends PlayerBindActivity {

    private final ArrayList<SearchRow> rows = new ArrayList<>();
    private final ArrayList<Track> songs = new ArrayList<>();
    private final ArrayList<Track> allTracks = new ArrayList<>();
    private String currentQuery = "";
    private Prefs prefs;
    private SearchAdapter adapter;

    static class SearchRow {
        int type;
        Track track;
        String title;
        String sub;
        long albumId;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        prefs = new Prefs(this);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        final EditText input = findViewById(R.id.search_input);
        ListView list = findViewById(R.id.search_list);
        adapter = new SearchAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                handle(rows.get(position), input.getText().toString().trim());
            }
        });
        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                rebuild(s.toString().trim().toLowerCase(Locale.ROOT));
            }
        });
        rebuild("");
        input.requestFocus();
        new Thread(new Runnable() {
            @Override
            public void run() {
                final ArrayList<Track> loaded = Library.load(SearchActivity.this);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        allTracks.clear();
                        allTracks.addAll(loaded);
                        if (!currentQuery.isEmpty()) {
                            rebuild(currentQuery);
                        }
                    }
                });
            }
        }).start();
    }

    private void rebuild(String query) {
        currentQuery = query;
        rows.clear();
        songs.clear();
        if (query.isEmpty()) {
            for (String item : prefs.searchHistory()) {
                SearchRow row = new SearchRow();
                row.type = 3;
                row.title = item;
                row.sub = getString(R.string.type_history);
                rows.add(row);
            }
            if (!rows.isEmpty()) {
                SearchRow clear = new SearchRow();
                clear.type = 4;
                clear.title = getString(R.string.clear_history);
                rows.add(clear);
            }
            adapter.notifyDataSetChanged();
            return;
        }
        ArrayList<Track> all = allTracks;
        LinkedHashMap<String, Integer> artists = new LinkedHashMap<>();
        LinkedHashMap<String, long[]> albums = new LinkedHashMap<>();
        java.util.HashMap<String, String> albumNames = new java.util.HashMap<>();
        for (Track track : all) {
            if (Pinyin.matches(track.title, query) || Pinyin.matches(track.artist, query)
                    || Pinyin.matches(track.album == null ? "" : track.album, query)) {
                SearchRow row = new SearchRow();
                row.type = 0;
                row.track = track;
                row.title = track.title;
                row.sub = track.artist;
                rows.add(row);
                songs.add(track);
            }
            if (Pinyin.matches(track.artist, query)) {
                Integer count = artists.get(track.artist);
                artists.put(track.artist, count == null ? 1 : count + 1);
            }
            String album = track.album == null ? "" : track.album;
            if (Pinyin.matches(album, query)) {
                String key = track.albumId + "|" + album;
                long[] item = albums.get(key);
                if (item == null) {
                    albums.put(key, new long[]{track.albumId, 1});
                    albumNames.put(key, album);
                } else {
                    item[1]++;
                }
            }
        }
        int count = 0;
        for (Map.Entry<String, Integer> entry : artists.entrySet()) {
            if (count++ >= 6) {
                break;
            }
            SearchRow row = new SearchRow();
            row.type = 1;
            row.title = entry.getKey();
            row.sub = getString(R.string.song_count_short, entry.getValue());
            rows.add(row);
        }
        count = 0;
        for (Map.Entry<String, long[]> entry : albums.entrySet()) {
            if (count++ >= 6) {
                break;
            }
            SearchRow row = new SearchRow();
            row.type = 2;
            row.albumId = entry.getValue()[0];
            row.title = albumNames.get(entry.getKey());
            row.sub = getString(R.string.song_count_short, entry.getValue()[1]);
            rows.add(row);
        }
        adapter.notifyDataSetChanged();
    }

    private void handle(SearchRow row, String query) {
        if (row.type == 3) {
            EditText input = findViewById(R.id.search_input);
            input.setText(row.title);
            input.setSelection(input.getText().length());
            return;
        }
        if (row.type == 4) {
            prefs.clearSearchHistory();
            rebuild("");
            return;
        }
        if (!query.isEmpty()) {
            prefs.addSearchHistory(query);
        }
        if (row.type == 0) {
            startService(new Intent(this, PlayerService.class));
            int index = songs.indexOf(row.track);
            if (service != null && index >= 0) {
                service.setQueue(new ArrayList<>(songs), index);
            }
            finish();
        } else if (row.type == 1) {
            Intent intent = new Intent(this, ArtistDetailActivity.class);
            intent.putExtra(ArtistDetailActivity.EXTRA_ARTIST, row.title);
            startActivity(intent);
        } else {
            Intent intent = new Intent(this, AlbumDetailActivity.class);
            intent.putExtra(AlbumDetailActivity.EXTRA_ALBUM_ID, row.albumId);
            intent.putExtra(AlbumDetailActivity.EXTRA_ALBUM_NAME, row.title);
            startActivity(intent);
        }
    }

    private class SearchAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public SearchRow getItem(int position) {
            return rows.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = getLayoutInflater().inflate(R.layout.item_search, parent, false);
            }
            SearchRow row = rows.get(position);
            TextView title = view.findViewById(R.id.sr_title);
            TextView sub = view.findViewById(R.id.sr_sub);
            TextView type = view.findViewById(R.id.sr_type);
            title.setText(row.title);
            sub.setText(row.sub);
            if (row.type == 0) {
                type.setText(R.string.type_song);
            } else if (row.type == 1) {
                type.setText(R.string.type_artist);
            } else if (row.type == 2) {
                type.setText(R.string.type_album);
            } else if (row.type == 4) {
                type.setText("");
            } else {
                type.setText(R.string.type_history);
            }
            return view;
        }
    }
}
