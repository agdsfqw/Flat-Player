package com.flatplayer.neo;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** 应用内使用指南：读取 assets/user_guide.md。 */
public class HelpActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        TextView text = findViewById(R.id.help_text);
        try {
            String asset = java.util.Locale.getDefault().getLanguage().startsWith("zh")
                    ? "user_guide.md" : "user_guide_en.md";
            InputStream in = getAssets().open(asset);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            in.close();
            text.setText(out.toString("UTF-8"));
        } catch (Exception e) {
            text.setText(getString(R.string.user_guide) + "\n\n" + e.getMessage());
        }
    }
}
