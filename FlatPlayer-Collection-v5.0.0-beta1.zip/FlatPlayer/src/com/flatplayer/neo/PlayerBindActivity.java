package com.flatplayer.neo;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;

import java.util.ArrayList;
import java.util.List;

/** 需要播放能力的二级页面基类：绑定服务、提供播放队列的入口。 */
public abstract class PlayerBindActivity extends BaseActivity implements PlayerService.Listener {

    protected PlayerService service;
    private boolean bound;
    private ArrayList<Track> pendingTracks;
    private int pendingStart;

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = ((PlayerService.LocalBinder) binder).service();
            service.addListener(PlayerBindActivity.this);
            onServiceReady();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            service = null;
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        if (!bound) {
            bindService(new Intent(this, PlayerService.class), connection, BIND_AUTO_CREATE);
            bound = true;
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (service != null) {
            service.removeListener(this);
        }
        if (bound) {
            unbindService(connection);
            bound = false;
        }
        service = null;
    }

    protected void onServiceReady() {
        if (pendingTracks != null) {
            service.setQueue(pendingTracks, pendingStart);
            pendingTracks = null;
        }
    }

    protected void playQueue(List<Track> tracks, int start) {
        if (tracks == null || tracks.isEmpty()) {
            return;
        }
        startService(new Intent(this, PlayerService.class));
        if (service != null) {
            service.setQueue(new ArrayList<>(tracks), Math.max(0, start));
        } else {
            pendingTracks = new ArrayList<>(tracks);
            pendingStart = Math.max(0, start);
        }
    }

    @Override
    public void onStateChanged() {
    }

    @Override
    public void onError(String message) {
    }
}
