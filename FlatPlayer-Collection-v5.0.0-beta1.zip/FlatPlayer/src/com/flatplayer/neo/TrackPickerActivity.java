package com.flatplayer.neo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/** 批量选歌（用于往歌单里一次性添加多首）。 */
public class TrackPickerActivity extends BaseActivity {

    private final ArrayList<Track> tracks = new ArrayList<>();
    private final Set<String> checked = new HashSet<>();
    private ListView list;
    private TextView addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picker);
        list = findViewById(R.id.pick_list);
        addButton = findViewById(R.id.pick_add);
        list.setAdapter(new PickerAdapter());

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.pick_all).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (Track track : tracks) {
                    checked.add(track.uri);
                }
                update();
            }
        });
        findViewById(R.id.pick_none).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checked.clear();
                update();
            }
        });
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String uri = tracks.get(position).uri;
                if (checked.contains(uri)) {
                    checked.remove(uri);
                } else {
                    checked.add(uri);
                }
                update();
            }
        });
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent data = new Intent();
                data.putStringArrayListExtra("uris", new ArrayList<>(checked));
                setResult(RESULT_OK, data);
                finish();
            }
        });

        new Thread(new Runnable() {
            @Override
            public void run() {
                final ArrayList<Track> loaded = Library.load(TrackPickerActivity.this);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tracks.clear();
                        tracks.addAll(loaded);
                        update();
                    }
                });
            }
        }).start();
    }

    private void update() {
        ((BaseAdapter) list.getAdapter()).notifyDataSetChanged();
        addButton.setText(getString(R.string.add_selected)
                + (checked.isEmpty() ? "" : "（" + checked.size() + "）"));
    }

    private class PickerAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return tracks.size();
        }

        @Override
        public Track getItem(int position) {
            return tracks.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = getLayoutInflater().inflate(R.layout.item_hidden, parent, false);
            }
            Track track = tracks.get(position);
            TextView title = view.findViewById(R.id.h_title);
            TextView artist = view.findViewById(R.id.h_artist);
            CheckBox check = view.findViewById(R.id.h_check);
            title.setText(track.title);
            artist.setText(track.artist);
            check.setChecked(checked.contains(track.uri));
            return view;
        }
    }
}
