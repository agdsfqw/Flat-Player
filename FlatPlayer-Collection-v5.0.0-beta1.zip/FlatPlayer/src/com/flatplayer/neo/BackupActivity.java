package com.flatplayer.neo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.OutputStream;
import java.util.ArrayList;

/** 备份、恢复与失效索引清理。 */
public class BackupActivity extends BaseActivity {

    private static final int REQ_EXPORT = 41;
    private static final int REQ_IMPORT = 42;

    private Prefs prefs;
    private String pendingExport;
    private String pendingImport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_category);
        prefs = new Prefs(this);
        ((TextView) findViewById(R.id.category_title)).setText(R.string.backup_title);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        LinearLayout list = findViewById(R.id.category_list);
        list.addView(SettingsUi.row(this, getString(R.string.export_data),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        exportData();
                    }
                }));
        list.addView(SettingsUi.row(this, getString(R.string.import_data),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        importData();
                    }
                }));
        SettingsUi.divider(this, list);
        list.addView(SettingsUi.row(this, getString(R.string.cleanup_missing),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        cleanupMissing();
                    }
                }));
    }

    private void cleanupMissing() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                ArrayList<Track> kept = new ArrayList<>();
                int removed = 0;
                for (Track track : SafStore.tracks(BackupActivity.this)) {
                    try {
                        java.io.InputStream in = getContentResolver()
                                .openInputStream(android.net.Uri.parse(track.uri));
                        if (in != null) {
                            in.close();
                            kept.add(track);
                        } else {
                            removed++;
                        }
                    } catch (Exception e) {
                        removed++;
                    }
                }
                SafStore.setTracks(BackupActivity.this, kept);
                prefs.markLibraryChanged();
                final int count = removed;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing()) {
                            Toast.makeText(BackupActivity.this,
                                    getString(R.string.cleanup_done, count), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }).start();
    }

    private void exportData() {
        try {
            JSONObject root = new JSONObject();
            root.put("app", "flatplayer");
            root.put("backup_version", 1);
            root.put("created", System.currentTimeMillis());
            root.put("prefs", prefs.exportAll());
            JSONArray playlists = new JSONArray();
            for (Playlist playlist : PlaylistStore.load(this)) {
                playlists.put(playlist.toJson());
            }
            root.put("playlists", playlists);
            JSONObject art = new JSONObject();
            File artDir = new File(getFilesDir(), "custom_art");
            File[] files = artDir.listFiles();
            long total = 0;
            if (files != null) {
                for (File file : files) {
                    if (!file.isFile() || total + file.length() > 12L * 1024 * 1024) {
                        continue;
                    }
                    byte[] bytes = new byte[(int) file.length()];
                    java.io.FileInputStream in = new java.io.FileInputStream(file);
                    int read = in.read(bytes);
                    in.close();
                    if (read > 0) {
                        art.put(file.getName(), android.util.Base64.encodeToString(
                                bytes, android.util.Base64.NO_WRAP));
                        total += read;
                    }
                }
            }
            root.put("art", art);
            pendingExport = root.toString(2);
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE, "flatplayer-backup-" + System.currentTimeMillis() + ".json");
            startActivityForResult(intent, REQ_EXPORT);
        } catch (Exception e) {
            Toast.makeText(this, R.string.export_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private void importData() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQ_IMPORT);
    }

    private void applyBackup(String text) {
        try {
            JSONObject root = new JSONObject(text);
            JSONObject prefsJson = root.optJSONObject("prefs");
            if (prefsJson == null) {
                Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.importAll(prefsJson);
            JSONObject art = root.optJSONObject("art");
            if (art != null) {
                File artDir = new File(getFilesDir(), "custom_art");
                artDir.mkdirs();
                java.util.Iterator<String> names = art.keys();
                while (names.hasNext()) {
                    String name = names.next();
                    try {
                        byte[] bytes = android.util.Base64.decode(
                                art.optString(name), android.util.Base64.NO_WRAP);
                        File file = new File(artDir, name);
                        java.io.FileOutputStream out = new java.io.FileOutputStream(file);
                        out.write(bytes);
                        out.close();
                    } catch (Exception ignored) {
                        // 跳过损坏封面
                    }
                }
            }
            JSONArray playlists = root.optJSONArray("playlists");
            if (playlists != null) {
                ArrayList<Playlist> list = new ArrayList<>();
                for (int i = 0; i < playlists.length(); i++) {
                    JSONObject item = playlists.optJSONObject(i);
                    if (item != null) {
                        list.add(Playlist.fromJson(item));
                    }
                }
                PlaylistStore.save(this, list);
            }
            prefs.markLibraryChanged();
            Toast.makeText(this, R.string.import_done, Toast.LENGTH_SHORT).show();
            recreate();
        } catch (Exception e) {
            Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMPORT && resultCode == RESULT_OK && data != null
                && data.getData() != null) {
            try {
                java.io.InputStream in = getContentResolver().openInputStream(data.getData());
                java.io.BufferedReader reader = new java.io.BufferedReader(
                        new java.io.InputStreamReader(in, "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line).append('\n');
                }
                reader.close();
                pendingImport = sb.toString();
                new AlertDialog.Builder(this)
                        .setTitle(R.string.import_data)
                        .setMessage(R.string.import_confirm)
                        .setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                applyBackup(pendingImport);
                                pendingImport = null;
                            }
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show();
            } catch (Exception e) {
                Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show();
            }
            return;
        }
        if (requestCode != REQ_EXPORT || resultCode != RESULT_OK || data == null
                || data.getData() == null || pendingExport == null) {
            return;
        }
        try {
            OutputStream out = getContentResolver().openOutputStream(data.getData());
            if (out != null) {
                out.write(pendingExport.getBytes("UTF-8"));
                out.close();
            }
            Toast.makeText(this, R.string.export_done, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, R.string.export_failed, Toast.LENGTH_SHORT).show();
        } finally {
            pendingExport = null;
        }
    }
}
