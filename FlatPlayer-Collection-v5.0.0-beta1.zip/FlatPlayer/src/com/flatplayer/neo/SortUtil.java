package com.flatplayer.neo;

import android.content.Context;
import android.text.TextUtils;

import org.json.JSONObject;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

/** 统一排序：标题、艺术家、专辑、时长、添加时间、播放次数、最近播放、文件夹。 */
public final class SortUtil {

    public static final int TITLE = 0;
    public static final int TITLE_DESC = 1;
    public static final int ARTIST = 2;
    public static final int ALBUM = 3;
    public static final int DURATION_ASC = 4;
    public static final int DURATION_DESC = 5;
    public static final int ADDED = 6;
    public static final int PLAYED = 7;
    public static final int RECENT = 8;
    public static final int FOLDER = 9;

    private SortUtil() {
    }

    public static String label(Context context, int mode) {
        switch (mode) {
            case TITLE_DESC:
                return context.getString(R.string.sort_title_desc);
            case ARTIST:
                return context.getString(R.string.sort_artist);
            case ALBUM:
                return context.getString(R.string.sort_album);
            case DURATION_ASC:
                return context.getString(R.string.sort_duration_asc);
            case DURATION_DESC:
                return context.getString(R.string.sort_duration_desc);
            case ADDED:
                return context.getString(R.string.sort_added);
            case PLAYED:
                return context.getString(R.string.sort_played);
            case RECENT:
                return context.getString(R.string.sort_recent);
            case FOLDER:
                return context.getString(R.string.sort_folder);
            default:
                return context.getString(R.string.sort_title);
        }
    }

    public static void sort(List<Track> tracks, int mode, Context context) {
        if (tracks == null || tracks.size() < 2) {
            return;
        }
        switch (mode) {
            case TITLE_DESC:
                Collections.sort(tracks, new Comparator<Track>() {
                    @Override
                    public int compare(Track a, Track b) {
                        return b.title.compareToIgnoreCase(a.title);
                    }
                });
                break;
            case ARTIST:
                Collections.sort(tracks, new Comparator<Track>() {
                    @Override
                    public int compare(Track a, Track b) {
                        int result = a.artist.compareToIgnoreCase(b.artist);
                        return result != 0 ? result : a.title.compareToIgnoreCase(b.title);
                    }
                });
                break;
            case ALBUM:
                Collections.sort(tracks, new Comparator<Track>() {
                    @Override
                    public int compare(Track a, Track b) {
                        int result = compareText(a.album, b.album);
                        return result != 0 ? result : a.title.compareToIgnoreCase(b.title);
                    }
                });
                break;
            case DURATION_ASC:
                Collections.sort(tracks, new Comparator<Track>() {
                    @Override
                    public int compare(Track a, Track b) {
                        return Long.compare(a.duration, b.duration);
                    }
                });
                break;
            case DURATION_DESC:
                Collections.sort(tracks, new Comparator<Track>() {
                    @Override
                    public int compare(Track a, Track b) {
                        return Long.compare(b.duration, a.duration);
                    }
                });
                break;
            case ADDED:
                Collections.sort(tracks, new Comparator<Track>() {
                    @Override
                    public int compare(Track a, Track b) {
                        return Long.compare(b.dateAdded, a.dateAdded);
                    }
                });
                break;
            case PLAYED:
                final HashMap<String, Integer> counts = playCounts(context);
                Collections.sort(tracks, new Comparator<Track>() {
                    @Override
                    public int compare(Track a, Track b) {
                        Integer ca = counts.get(a.uri);
                        Integer cb = counts.get(b.uri);
                        int result = Integer.compare(cb == null ? 0 : cb, ca == null ? 0 : ca);
                        return result != 0 ? result : a.title.compareToIgnoreCase(b.title);
                    }
                });
                break;
            case RECENT:
                final HashMap<String, Integer> recent = recentIndex(context);
                Collections.sort(tracks, new Comparator<Track>() {
                    @Override
                    public int compare(Track a, Track b) {
                        Integer ia = recent.get(a.uri);
                        Integer ib = recent.get(b.uri);
                        int result = Integer.compare(ia == null ? Integer.MAX_VALUE : ia,
                                ib == null ? Integer.MAX_VALUE : ib);
                        return result != 0 ? result : a.title.compareToIgnoreCase(b.title);
                    }
                });
                break;
            case FOLDER:
                Collections.sort(tracks, new Comparator<Track>() {
                    @Override
                    public int compare(Track a, Track b) {
                        int result = compareText(a.bucketName, b.bucketName);
                        return result != 0 ? result : a.title.compareToIgnoreCase(b.title);
                    }
                });
                break;
            default:
                Collections.sort(tracks, new Comparator<Track>() {
                    @Override
                    public int compare(Track a, Track b) {
                        return a.title.compareToIgnoreCase(b.title);
                    }
                });
                break;
        }
    }

    private static int compareText(String a, String b) {
        String left = a == null ? "" : a;
        String right = b == null ? "" : b;
        return left.compareToIgnoreCase(right);
    }

    private static HashMap<String, Integer> playCounts(Context context) {
        HashMap<String, Integer> map = new HashMap<>();
        JSONObject stats = new Prefs(context).stats();
        java.util.Iterator<String> keys = stats.keys();
        while (keys.hasNext()) {
            String uri = keys.next();
            JSONObject item = stats.optJSONObject(uri);
            if (item != null) {
                map.put(uri, item.optInt("c"));
            }
        }
        return map;
    }

    private static HashMap<String, Integer> recentIndex(Context context) {
        HashMap<String, Integer> map = new HashMap<>();
        java.util.List<String> recent = new Prefs(context).recent();
        for (int i = 0; i < recent.size(); i++) {
            map.put(recent.get(i), i);
        }
        return map;
    }
}
