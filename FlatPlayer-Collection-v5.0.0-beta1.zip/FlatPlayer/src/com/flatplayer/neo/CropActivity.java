package com.flatplayer.neo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.io.InputStream;

/** 裁切自定义封面/头像：方形取景，导出后写入私有目录。 */
public class CropActivity extends BaseActivity {

    public static final String EXTRA_IMAGE = "image_uri";
    public static final String EXTRA_KEY = "custom_key";

    private CropView cropView;
    private String key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop);
        cropView = findViewById(R.id.crop_view);
        key = getIntent().getStringExtra(EXTRA_KEY);
        String image = getIntent().getStringExtra(EXTRA_IMAGE);

        findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.save).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });

        if (image != null) {
            loadImage(Uri.parse(image));
        } else {
            finish();
        }
    }

    private void loadImage(final Uri uri) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Bitmap bitmap = null;
                try {
                    BitmapFactory.Options bounds = new BitmapFactory.Options();
                    bounds.inJustDecodeBounds = true;
                    InputStream in1 = getContentResolver().openInputStream(uri);
                    BitmapFactory.decodeStream(in1, null, bounds);
                    if (in1 != null) {
                        in1.close();
                    }
                    int sample = 1;
                    int max = Math.max(bounds.outWidth, bounds.outHeight);
                    while (max / (sample * 2) > 2048) {
                        sample *= 2;
                    }
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inSampleSize = sample;
                    InputStream in2 = getContentResolver().openInputStream(uri);
                    bitmap = BitmapFactory.decodeStream(in2, null, options);
                    if (in2 != null) {
                        in2.close();
                    }
                } catch (Throwable ignored) {
                    // 读取失败下面提示
                }
                final Bitmap result = bitmap;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (result == null) {
                            Toast.makeText(CropActivity.this, "无法读取图片", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            cropView.setBitmap(result);
                        }
                    }
                });
            }
        }).start();
    }

    private void save() {
        Bitmap cropped = cropView.export();
        if (cropped == null) {
            Toast.makeText(this, "没有可保存的内容", Toast.LENGTH_SHORT).show();
            return;
        }
        Bitmap scaled = Bitmap.createScaledBitmap(cropped, 512, 512, true);
        CustomArtStore.save(this, key, scaled);
        ArtLoader.clearMemory();
        Toast.makeText(this, R.string.cover_saved, Toast.LENGTH_SHORT).show();
        setResult(RESULT_OK);
        finish();
    }
}
