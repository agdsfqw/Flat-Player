package com.flatplayer.neo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Track {

    public final long id;
    public final String uri;
    public final String title;
    public final String artist;
    public final String album;
    public final long albumId;
    public final long duration;
    public final String displayName;
    public final String relativePath;
    public final String bucketKey;
    public final String bucketName;
    public final int year;
    public final long dateAdded;
    public final String lyricUri;

    public Track(long id, String uri, String title, String artist, String album,
                 long albumId, long duration, String displayName, String relativePath,
                 String bucketKey, String bucketName, int year, long dateAdded, String lyricUri) {
        this.id = id;
        this.uri = uri;
        this.title = title;
        this.artist = artist;
        this.album = album;
        this.albumId = albumId;
        this.duration = duration;
        this.displayName = displayName;
        this.relativePath = relativePath;
        this.bucketKey = bucketKey;
        this.bucketName = bucketName;
        this.year = year;
        this.dateAdded = dateAdded;
        this.lyricUri = lyricUri == null ? "" : lyricUri;
    }

    public static String format(long ms) {
        if (ms < 0) {
            ms = 0;
        }
        long total = ms / 1000;
        return String.format("%d:%02d", total / 60, total % 60);
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("uri", uri);
        o.put("title", title);
        o.put("artist", artist);
        o.put("album", album);
        o.put("albumId", albumId);
        o.put("duration", duration);
        o.put("displayName", displayName == null ? "" : displayName);
        o.put("relativePath", relativePath == null ? "" : relativePath);
        o.put("bucketKey", bucketKey == null ? "" : bucketKey);
        o.put("bucketName", bucketName == null ? "" : bucketName);
        o.put("year", year);
        o.put("dateAdded", dateAdded);
        o.put("lyricUri", lyricUri);
        return o;
    }

    public static Track fromJson(JSONObject o) {
        return new Track(
                o.optLong("id"),
                o.optString("uri"),
                o.optString("title", "未命名"),
                o.optString("artist", "未知艺术家"),
                o.optString("album", ""),
                o.optLong("albumId"),
                o.optLong("duration"),
                o.optString("displayName", ""),
                o.optString("relativePath", ""),
                o.optString("bucketKey", ""),
                o.optString("bucketName", ""),
                o.optInt("year"),
                o.optLong("dateAdded"),
                o.optString("lyricUri", ""));
    }

    public static String listToJson(List<Track> list) {
        JSONArray array = new JSONArray();
        for (Track t : list) {
            try {
                array.put(t.toJson());
            } catch (JSONException ignored) {
                // 跳过异常项
            }
        }
        return array.toString();
    }

    public static ArrayList<Track> listFromJson(String json) {
        ArrayList<Track> out = new ArrayList<>();
        if (json == null || json.isEmpty()) {
            return out;
        }
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.optJSONObject(i);
                if (o != null) {
                    out.add(fromJson(o));
                }
            }
        } catch (JSONException ignored) {
            // 数据损坏时返回空
        }
        return out;
    }
}
