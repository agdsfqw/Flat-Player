package com.flatplayer.neo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.media.audiofx.Equalizer;
import android.animation.ValueAnimator;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.json.JSONArray;

import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PlayerService extends Service
        implements MediaPlayer.OnPreparedListener,
        MediaPlayer.OnCompletionListener,
        MediaPlayer.OnErrorListener,
        AudioManager.OnAudioFocusChangeListener {

    public interface Listener {
        void onStateChanged();

        void onError(String message);
    }

    public static final String ACTION_TOGGLE = "com.flatplayer.neo.TOGGLE";
    public static final String ACTION_NEXT = "com.flatplayer.neo.NEXT";
    public static final String ACTION_PREV = "com.flatplayer.neo.PREV";

    public static final int MODE_SEQUENCE = 0;
    public static final int MODE_REPEAT = 1;
    public static final int MODE_SHUFFLE = 2;

    private static final String CHANNEL_ID = "playback_v2";
    private static final int NOTIFICATION_ID = 1001;

    private final ArrayList<Track> queue = new ArrayList<>();
    private final Random random = new Random();
    private MediaPlayer player;
    private int index = -1;
    private boolean prepared;
    private boolean preparing;
    private boolean playing;
    private boolean foreground;
    private boolean usingFd;
    private boolean resumeOnFocus;
    private int mode = MODE_SEQUENCE;
    private int pendingSeek;
    private boolean pendingAuto;
    private int lastSeek;
    private boolean lastAuto = true;

    private Bitmap artwork;
    private int artToken;

    private long sleepUntil;
    private boolean sleepFinish;
    private boolean stopAfterCurrent;
    private boolean sleepReached;
    private float speed = 1f;
    private float fadeSeconds;
    private int abStart = -1;
    private int abEnd = -1;
    private ValueAnimator fadeAnimator;
    private Equalizer equalizer;
    private boolean equalizerReady;
    private int eqSession = -1;
    private android.media.AudioDeviceCallback deviceCallback;
    private String lastWidgetTitle = "";
    private boolean lastWidgetPlaying;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Runnable sleepFadeRunnable = new Runnable() {
        @Override
        public void run() {
            if (playing && player != null) {
                fadeVolume(1f, 0f, 20000);
            }
        }
    };
    private final Handler handler = new Handler(Looper.getMainLooper());
    /** 每秒刷新一次播放位置，Android 13+ 的系统媒体面板进度条才能平滑走动。 */
    private final Runnable positionTicker = new Runnable() {
        @Override
        public void run() {
            if (playing) {
                checkAbLoop();
                updateSession();
                handler.postDelayed(this, 1000);
            }
        }
    };

    private final Runnable sleepRunnable = new Runnable() {
        @Override
        public void run() {
            sleepUntil = 0;
            sleepReached = true;
            if (sleepFinish) {
                stopAfterCurrent = true;
            } else if (playing) {
                pauseInternal(false);
            }
            sync();
        }
    };

    private final BroadcastReceiver noisyReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(intent.getAction())
                    && playing && new Prefs(PlayerService.this).headset()) {
                pauseInternal(true);
            }
        }
    };

    private final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private MediaSession session;
    private AudioManager audioManager;
    private Prefs prefs;

    private static final ExecutorService SAVE_EXECUTOR = Executors.newSingleThreadExecutor();
    private final IBinder binder = new LocalBinder();

    public class LocalBinder extends Binder {
        public PlayerService service() {
            return PlayerService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = new Prefs(this);
        speed = prefs.speed();
        fadeSeconds = prefs.fadeSeconds();
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        createChannel();
        try {
            android.app.NotificationManager nm =
                    (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.cancelAll();
            }
        } catch (Throwable ignored) {
            // 忽略
        }
        session = new MediaSession(this, "FlatPlayer");
        session.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() {
                if (!playing) {
                    toggle();
                }
            }

            @Override
            public void onPause() {
                if (playing) {
                    toggle();
                }
            }

            @Override
            public void onSkipToNext() {
                next();
            }

            @Override
            public void onSkipToPrevious() {
                prev();
            }

            @Override
            public void onSeekTo(long pos) {
                seekTo((int) pos);
            }
        });
        session.setActive(true);

        if (Build.VERSION.SDK_INT >= 23 && audioManager != null) {
            try {
                deviceCallback = new android.media.AudioDeviceCallback() {
                    @Override
                    public void onAudioDevicesAdded(android.media.AudioDeviceInfo[] addedDevices) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                applyEqualizer();
                            }
                        });
                    }

                    @Override
                    public void onAudioDevicesRemoved(android.media.AudioDeviceInfo[] removedDevices) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                applyEqualizer();
                            }
                        });
                    }
                };
                audioManager.registerAudioDeviceCallback(deviceCallback, mainHandler);
            } catch (Throwable ignored) {
                // 忽略
            }
        }

        IntentFilter filter = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(noisyReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(noisyReceiver, filter);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String action = intent.getAction();
            if (ACTION_TOGGLE.equals(action)) {
                toggle();
            } else if (ACTION_NEXT.equals(action)) {
                next();
            } else if (ACTION_PREV.equals(action)) {
                prev();
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onDestroy() {
        listeners.clear();
        saveState();
        handler.removeCallbacks(sleepRunnable);
        handler.removeCallbacks(positionTicker);
        try {
            unregisterReceiver(noisyReceiver);
        } catch (IllegalArgumentException ignored) {
            // 未注册成功
        }
        if (deviceCallback != null && audioManager != null) {
            try {
                audioManager.unregisterAudioDeviceCallback(deviceCallback);
            } catch (Throwable ignored) {
                // 忽略
            }
            deviceCallback = null;
        }
        if (equalizer != null) {
            try {
                equalizer.release();
            } catch (Throwable ignored) {
                // 忽略
            }
            equalizer = null;
        }
        if (player != null) {
            player.release();
            player = null;
        }
        if (session != null) {
            session.setActive(false);
            session.release();
            session = null;
        }
        if (foreground) {
            stopForeground(true);
            foreground = false;
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------ 对外接口

    public void addListener(Listener l) {
        if (l != null && !listeners.contains(l)) {
            listeners.add(l);
        }
    }

    public void removeListener(Listener l) {
        listeners.remove(l);
    }

    public boolean hasQueue() {
        return !queue.isEmpty();
    }

    public List<Track> getQueue() {
        return new ArrayList<>(queue);
    }

    public int getIndex() {
        return index;
    }

    public boolean isPlaying() {
        return playing;
    }

    public int getMode() {
        return mode;
    }

    public int cycleMode() {
        mode = (mode + 1) % 3;
        sync();
        return mode;
    }

    public Track currentTrack() {
        if (index >= 0 && index < queue.size()) {
            return queue.get(index);
        }
        return null;
    }

    public int getPosition() {
        if (prepared && player != null) {
            try {
                return player.getCurrentPosition();
            } catch (IllegalStateException ignored) {
                return 0;
            }
        }
        return 0;
    }

    public int getDuration() {
        if (prepared && player != null) {
            try {
                int d = player.getDuration();
                if (d > 0) {
                    return d;
                }
            } catch (IllegalStateException ignored) {
                // 回退
            }
        }
        Track t = currentTrack();
        return t == null ? 0 : (int) t.duration;
    }

    public void setQueue(List<Track> tracks, int start) {
        setQueue(tracks, start, 0, true);
    }

    public void setQueue(List<Track> tracks, int start, int position, boolean autoPlay) {
        queue.clear();
        queue.addAll(tracks);
        if (queue.isEmpty()) {
            stopSelf();
            return;
        }
        playAt(start, position, autoPlay);
    }

    public void playAt(int i) {
        playAt(i, 0, true);
    }

    private void playAt(int i, int seekPos, boolean autoPlay) {
        if (i < 0 || i >= queue.size()) {
            return;
        }
        index = i;
        abStart = -1;
        abEnd = -1;
        prepared = false;
        preparing = true;
        playing = false;
        pendingSeek = Math.max(0, seekPos);
        pendingAuto = autoPlay;
        loadArtwork(queue.get(i));
        lastSeek = pendingSeek;
        lastAuto = autoPlay;
        usingFd = false;
        saveState();
        open(i, false);
    }

    private void open(int i, boolean viaFd) {
        Track target = queue.get(i);
        if (player == null) {
            player = new MediaPlayer();
            player.setOnPreparedListener(this);
            player.setOnCompletionListener(this);
            player.setOnErrorListener(this);
        }
        try {
            player.reset();
            player.setAudioAttributes(audioAttributes());
            if (!viaFd) {
                player.setDataSource(this, android.net.Uri.parse(target.uri));
            } else {
                ParcelFileDescriptor pfd = getContentResolver()
                        .openFileDescriptor(android.net.Uri.parse(target.uri), "r");
                if (pfd == null) {
                    throw new IllegalStateException("openFileDescriptor 返回空");
                }
                player.setDataSource(pfd.getFileDescriptor());
                pfd.close();
            }
            usingFd = viaFd;
            player.prepareAsync();
        } catch (Exception e) {
            preparing = false;
            playing = false;
            if (!viaFd) {
                usingFd = true;
                open(i, true);
                return;
            }
            notifyError("无法打开音频：" + e.getMessage());
            sync();
            return;
        }
        sync();
    }

    public void toggle() {
        if (preparing) {
            return;
        }
        if (player == null || !prepared) {
            if (!queue.isEmpty()) {
                playAt(index < 0 ? 0 : index);
            }
            return;
        }
        if (playing) {
            pauseInternal(true);
        } else {
            ensureStarted();
            grabFocus();
            try {
                player.setVolume(1f, 1f);
                player.start();
            } catch (IllegalStateException e) {
                notifyError("恢复播放失败：" + e.getMessage());
                return;
            }
            playing = true;
            promote();
            handler.post(positionTicker);
            sync();
        }
    }

    private void pauseInternal(boolean save) {
        handler.removeCallbacks(positionTicker);
        if (fadeAnimator != null) {
            fadeAnimator.cancel();
            fadeAnimator = null;
        }
        if (player != null && prepared) {
            try {
                player.pause();
                // 定时淡出会把音量降到 0，暂停后必须还原，否则下次播放无声
                player.setVolume(1f, 1f);
            } catch (IllegalStateException ignored) {
                // 忽略
            }
        }
        playing = false;
        resumeOnFocus = false;
        if (save) {
            saveState();
            saveLastPosition();
        }
        sync();
    }

    public void next() {
        if (queue.isEmpty()) {
            return;
        }
        if (mode == MODE_SHUFFLE && queue.size() > 1) {
            int n;
            do {
                n = random.nextInt(queue.size());
            } while (n == index);
            playWithFade(n);
            return;
        }
        playWithFade((index + 1) % queue.size());
    }

    private void playWithFade(final int target) {
        if (playing && fadeSeconds > 0) {
            fadeOutThen(new Runnable() {
                @Override
                public void run() {
                    playAt(target);
                }
            });
        } else {
            playAt(target);
        }
    }

    public void prev() {
        if (queue.isEmpty()) {
            return;
        }
        if (prepared && player != null && getPosition() > 3000) {
            seekTo(0);
            return;
        }
        if (mode == MODE_SHUFFLE && queue.size() > 1) {
            int n;
            do {
                n = random.nextInt(queue.size());
            } while (n == index);
            playWithFade(n);
            return;
        }
        playWithFade(index <= 0 ? queue.size() - 1 : index - 1);
    }

    public void seekTo(int ms) {
        if (prepared && player != null) {
            try {
                player.seekTo(ms);
            } catch (IllegalStateException ignored) {
                return;
            }
            sync();
        }
    }

    public void retry() {
        if (index >= 0 && index < queue.size()) {
            usingFd = false;
            prepared = false;
            preparing = true;
            playing = false;
            open(index, false);
        }
    }

    public void skip() {
        if (queue.size() > 1) {
            next();
        } else {
            pauseInternal(true);
        }
    }

    public void stopPlayback() {
        pauseInternal(true);
        if (foreground) {
            stopForeground(true);
            foreground = false;
        }
    }

    public void removeAt(int position) {
        if (position < 0 || position >= queue.size()) {
            return;
        }
        boolean current = position == index;
        queue.remove(position);
        if (queue.isEmpty()) {
            pauseInternal(true);
            stopSelf();
            return;
        }
        if (position < index) {
            index--;
        } else if (current) {
            index = Math.min(index, queue.size() - 1);
            playAt(index, 0, playing);
            return;
        }
        saveState();
        sync();
    }

    public void move(int from, int to) {
        if (from < 0 || from >= queue.size() || to < 0 || to >= queue.size() || from == to) {
            return;
        }
        Track track = queue.remove(from);
        queue.add(to, track);
        if (index == from) {
            index = to;
        } else if (from < index && to >= index) {
            index--;
        } else if (from > index && to <= index) {
            index++;
        }
        saveState();
        sync();
    }

    public void clearQueue() {
        try {
            handler.removeCallbacks(positionTicker);
            playing = false;
            preparing = false;
            prepared = false;
            if (player != null) {
                try {
                    player.reset();
                } catch (Throwable ignored) {
                    // 忽略
                }
            }
            queue.clear();
            index = -1;
            if (foreground) {
                try {
                    stopForeground(true);
                } catch (Throwable ignored) {
                    // 忽略
                }
                foreground = false;
            }
            sync();
        } catch (Throwable ignored) {
            // 清空失败不影响界面
        }
    }

    public void playNext(Track track) {
        if (track == null) {
            return;
        }
        int insertAt = Math.min(queue.size(), index + 1);
        queue.add(insertAt, track);
        saveState();
        sync();
    }

    public void setSleepMinutes(int minutes) {
        setSleepMinutes(minutes, false);
    }

    public void setSleepMinutes(int minutes, boolean finishCurrent) {
        handler.removeCallbacks(sleepRunnable);
        handler.removeCallbacks(sleepFadeRunnable);
        sleepFinish = finishCurrent;
        stopAfterCurrent = false;
        sleepReached = false;
        if (minutes <= 0) {
            sleepUntil = 0;
            if (player != null) {
                player.setVolume(1f, 1f);
            }
        } else {
            sleepUntil = System.currentTimeMillis() + minutes * 60000L;
            handler.postDelayed(sleepRunnable, minutes * 60000L);
            if (!sleepFinish) {
                long fadeDelay = minutes * 60000L - 20000L;
                if (fadeDelay > 0) {
                    handler.postDelayed(sleepFadeRunnable, fadeDelay);
                }
            }
        }
        sync();
    }

    public boolean isSleepFinishCurrent() {
        return sleepFinish;
    }

    public boolean isStopAfterCurrent() {
        return stopAfterCurrent;
    }

    public int getSleepMinutes() {
        if (sleepUntil <= 0) {
            return 0;
        }
        long left = sleepUntil - System.currentTimeMillis();
        return left <= 0 ? 0 : (int) Math.ceil(left / 60000.0);
    }

    public boolean restoreSaved() {
        if (!prefs.resume() || hasQueue()) {
            return false;
        }
        ArrayList<Track> saved = Track.listFromJson(prefs.queueJson());
        if (saved.isEmpty()) {
            return false;
        }
        queue.clear();
        queue.addAll(saved);
        int idx = Math.min(Math.max(0, prefs.queueIndex()), queue.size() - 1);
        playAt(idx, prefs.queuePos(), false);
        return true;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(float value) {
        speed = Math.max(0.5f, Math.min(2.0f, value));
        prefs.setSpeed(speed);
        applySpeed();
        sync();
    }

    private void applySpeed() {
        if (player == null || !prepared) {
            return;
        }
        try {
            PlaybackParams params = new PlaybackParams();
            params.setSpeed(speed);
            player.setPlaybackParams(params);
        } catch (Throwable ignored) {
            // 机型不支持时保持原速
        }
    }

    public void setFadeSeconds(float value) {
        fadeSeconds = Math.max(0f, Math.min(3f, value));
        prefs.setFadeSeconds(fadeSeconds);
    }

    public float getFadeSeconds() {
        return fadeSeconds;
    }

    private void fadeIn() {
        if (fadeSeconds <= 0 || player == null) {
            if (player != null) {
                player.setVolume(1f, 1f);
            }
            return;
        }
        fadeVolume(0f, 1f, (long) (fadeSeconds * 1000));
    }

    private void fadeOutThen(final Runnable action) {
        if (player == null || fadeSeconds <= 0) {
            action.run();
            return;
        }
        fadeVolume(1f, 0f, (long) (fadeSeconds * 1000), action);
    }

    private void fadeVolume(float from, float to, long duration) {
        fadeVolume(from, to, duration, null);
    }

    private void fadeVolume(final float from, final float to, long duration, final Runnable endAction) {
        if (fadeAnimator != null) {
            fadeAnimator.cancel();
        }
        fadeAnimator = ValueAnimator.ofFloat(from, to);
        fadeAnimator.setDuration(Math.max(1, duration));
        fadeAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float value = (Float) animation.getAnimatedValue();
                if (player != null) {
                    try {
                        player.setVolume(value, value);
                    } catch (IllegalStateException ignored) {
                        // 忽略
                    }
                }
            }
        });
        if (endAction != null) {
            fadeAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator animation) {
                    endAction.run();
                }
            });
        }
        fadeAnimator.start();
    }

    public void setAbStart() {
        abStart = getPosition();
        abEnd = -1;
        sync();
    }

    public void setAbEnd() {
        int position = getPosition();
        if (abStart >= 0 && position > abStart + 1000) {
            abEnd = position;
        }
        sync();
    }

    public void clearAb() {
        abStart = -1;
        abEnd = -1;
        sync();
    }

    public int getAbStart() {
        return abStart;
    }

    public int getAbEnd() {
        return abEnd;
    }

    private void checkAbLoop() {
        if (abStart >= 0 && abEnd > abStart && getPosition() >= abEnd) {
            seekTo(abStart);
        }
    }

    private void saveLastPosition() {
        Track track = currentTrack();
        if (track != null && track.duration > 10 * 60 * 1000L) {
            prefs.setLastPosition(track.uri, getPosition());
        }
    }

    // ------------------------------------------------------------ 均衡器

    private void ensureEqualizer() {
        if (player == null) {
            return;
        }
        int session;
        try {
            session = player.getAudioSessionId();
        } catch (Throwable t) {
            return;
        }
        if (equalizer != null && session == eqSession) {
            applyEqualizer();
            return;
        }
        if (equalizer != null) {
            try {
                equalizer.release();
            } catch (Throwable ignored) {
                // 忽略
            }
            equalizer = null;
        }
        try {
            equalizer = new Equalizer(0, session);
            eqSession = session;
            equalizerReady = true;
            applyEqualizer();
        } catch (Throwable t) {
            equalizer = null;
            equalizerReady = false;
            eqSession = -1;
        }
    }

    public boolean isEqualizerAvailable() {
        return equalizerReady && equalizer != null;
    }

    public int getOutputClass() {
        if (audioManager == null) {
            return 0;
        }
        try {
            boolean wired = false;
            boolean bluetooth = false;
            boolean usb = false;
            for (android.media.AudioDeviceInfo info
                    : audioManager.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
                int type = info.getType();
                if (type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES
                        || type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET
                        || type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET) {
                    wired = true;
                } else if (type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
                        || type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO) {
                    bluetooth = true;
                } else if (type == android.media.AudioDeviceInfo.TYPE_USB_DEVICE) {
                    usb = true;
                }
            }
            if (wired) {
                return 1;
            }
            if (bluetooth) {
                return 2;
            }
            return usb ? 3 : 0;
        } catch (Throwable t) {
            return 0;
        }
    }

    public int getEqualizerPreset() {
        return prefs.equalizerPreset(getOutputClass());
    }

    public void setEqualizerPreset(int preset) {
        prefs.setEqualizerPreset(getOutputClass(), preset);
        applyEqualizer();
    }

    public short[] getBandRange() {
        if (equalizer == null) {
            return new short[]{-1500, 1500};
        }
        try {
            return equalizer.getBandLevelRange();
        } catch (Throwable t) {
            return new short[]{-1500, 1500};
        }
    }

    public short getBandCount() {
        if (equalizer == null) {
            return 5;
        }
        try {
            return equalizer.getNumberOfBands();
        } catch (Throwable t) {
            return 5;
        }
    }

    public short[] getBandLevels() {
        short count = getBandCount();
        short[] levels = new short[count];
        if (equalizer != null) {
            try {
                for (short i = 0; i < count; i++) {
                    levels[i] = equalizer.getBandLevel(i);
                }
            } catch (Throwable ignored) {
                // 忽略
            }
        }
        return levels;
    }

    public void setCustomBands(short[] levels) {
        if (equalizer == null) {
            return;
        }
        try {
            for (short i = 0; i < levels.length && i < getBandCount(); i++) {
                equalizer.setBandLevel(i, levels[i]);
            }
            JSONArray array = new JSONArray();
            for (short level : levels) {
                array.put((int) level);
            }
            prefs.setEqualizerBands(getOutputClass(), array.toString());
            prefs.setEqualizerPreset(getOutputClass(), 6);
            equalizer.setEnabled(true);
        } catch (Throwable ignored) {
            // 忽略
        }
    }

    private void applyEqualizer() {
        if (equalizer == null) {
            return;
        }
        boolean mute = playing && player != null;
        if (mute) {
            try {
                player.setVolume(0f, 0f);
            } catch (Throwable ignored) {
                // 忽略
            }
        }
        try {
            equalizer.setEnabled(true);
            int preset = prefs.equalizerPreset(getOutputClass());
            short count = getBandCount();
            short[] range = getBandRange();
            short max = range[1];
            if (preset < 0) {
                for (short i = 0; i < count; i++) {
                    equalizer.setBandLevel(i, (short) 0);
                }
            } else if (preset >= 0 && preset <= 5) {
                float[] curve = presetCurve(preset);
                for (short i = 0; i < count; i++) {
                    float fraction = count <= 1 ? 0.5f : i / (float) (count - 1);
                    float value = interpolate(curve, fraction);
                    short level = (short) Math.max(-600, Math.min(600, value * max * 0.35f));
                    equalizer.setBandLevel(i, level);
                }
            } else if (preset == 6) {
                String json = prefs.equalizerBands(getOutputClass());
                JSONArray array = new JSONArray(json == null || json.isEmpty() ? "[]" : json);
                for (short i = 0; i < count && i < array.length(); i++) {
                    equalizer.setBandLevel(i, (short) array.optInt(i));
                }
            }
        } catch (Throwable ignored) {
            // 机型不支持时静默降级
        }
        if (mute) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (player != null && playing) {
                        try {
                            player.setVolume(1f, 1f);
                        } catch (Throwable ignored) {
                            // 忽略
                        }
                    }
                }
            }, 150);
        }
    }

    private float[] presetCurve(int preset) {
        switch (preset) {
            case 1:
                return new float[]{0.3f, 0.1f, 0.4f, 0.2f, 0.1f};
            case 2:
                return new float[]{0.6f, 0.3f, -0.1f, 0.4f, 0.6f};
            case 3:
                return new float[]{0.2f, 0.1f, 0.0f, 0.2f, 0.5f};
            case 4:
                return new float[]{-0.2f, 0.0f, 0.7f, 0.3f, -0.1f};
            case 5:
                return new float[]{0.9f, 0.6f, 0.0f, -0.1f, 0.0f};
            default:
                return new float[]{0f, 0f, 0f, 0f, 0f};
        }
    }

    private float interpolate(float[] curve, float fraction) {
        if (fraction <= 0f) {
            return curve[0];
        }
        if (fraction >= 1f) {
            return curve[curve.length - 1];
        }
        float position = fraction * (curve.length - 1);
        int index = (int) position;
        float mix = position - index;
        return curve[index] * (1 - mix) + curve[index + 1] * mix;
    }

    private void loadArtwork(final Track track) {
        final int token = ++artToken;
        artwork = null;
        ArtLoader.load(this, track.uri, 512, new ArtLoader.Callback() {
            @Override
            public void onArt(String uri, Bitmap bitmap) {
                if (token != artToken) {
                    return;
                }
                artwork = bitmap;
                updateSession();
                if (foreground) {
                    sync();
                }
            }
        });
    }

    private int getDurationSafe(MediaPlayer mp) {
        try {
            return mp.getDuration();
        } catch (IllegalStateException e) {
            return 0;
        }
    }

    private void saveState() {
        if (queue.isEmpty() || index < 0) {
            return;
        }
        final ArrayList<Track> snapshot = new ArrayList<>(queue);
        final int snapshotIndex = index;
        final int position = getPosition();
        SAVE_EXECUTOR.execute(new Runnable() {
            @Override
            public void run() {
                prefs.saveQueue(Track.listToJson(snapshot), snapshotIndex, position);
            }
        });
    }

    // ------------------------------------------------------------ MediaPlayer

    @Override
    public void onPrepared(MediaPlayer mp) {
        prepared = true;
        preparing = false;
        ensureEqualizer();
        if (pendingSeek > 0) {
            try {
                mp.seekTo(pendingSeek);
            } catch (IllegalStateException ignored) {
                // 忽略
            }
        }
        if (pendingAuto) {
            grabFocus();
            Track track = currentTrack();
            if (track != null && pendingSeek == 0 && track.duration > 10 * 60 * 1000L) {
                int last = prefs.getLastPosition(track.uri);
                if (last > 5000 && last < track.duration - 5000) {
                    try {
                        mp.seekTo(last);
                    } catch (IllegalStateException ignored) {
                        // 忽略
                    }
                }
            }
            applySpeed();
            mp.setVolume(fadeSeconds > 0 ? 0f : 1f, fadeSeconds > 0 ? 0f : 1f);
            mp.start();
            playing = true;
            if (track != null) {
                prefs.addRecent(track.uri);
            }
            fadeIn();
            promote();
            handler.post(positionTicker);
        }
        pendingSeek = 0;
        pendingAuto = false;
        saveState();
        sync();
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        saveLastPosition();
        if (stopAfterCurrent || (sleepFinish && sleepReached)) {
            stopAfterCurrent = false;
            sleepFinish = false;
            sleepReached = false;
            playing = false;
            prepared = true;
            try {
                mp.seekTo(0);
                mp.setVolume(1f, 1f);
            } catch (Throwable ignored) {
                // 忽略
            }
            saveState();
            sync();
            return;
        }
        Track completed = currentTrack();
        if (completed != null) {
            int duration = getDurationSafe(mp);
            prefs.addPlayed(completed.uri, duration > 0 ? duration : completed.duration);
        }
        if (mode == MODE_REPEAT) {
            try {
                mp.seekTo(0);
                mp.start();
                playing = true;
                sync();
            } catch (IllegalStateException ignored) {
                // 忽略
            }
            return;
        }
        if (queue.size() > 1) {
            Track finished = currentTrack();
            if (finished != null) {
                prefs.setLastPosition(finished.uri, 0);
            }
            if (mode == MODE_SHUFFLE) {
                int n;
                do {
                    n = random.nextInt(queue.size());
                } while (n == index);
                playAt(n);
            } else {
                playAt((index + 1) % queue.size());
            }
        } else {
            playing = false;
            saveState();
            sync();
        }
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        preparing = false;
        prepared = false;
        playing = false;
        if (!usingFd) {
            // 数据源兼容性兜底：改用文件描述符重试一次
            usingFd = true;
            prepared = false;
            preparing = true;
            pendingAuto = lastAuto;
            pendingSeek = lastSeek;
            open(index, true);
            return true;
        }
        notifyError("播放失败 code=" + what + " extra=" + extra);
        sync();
        return true;
    }

    // -------------------------------------------------------------- 通知等

    /** 确保服务处于 started 状态：否则 Activity 解绑时会被系统销毁，后台播放随之停止。 */
    private void ensureStarted() {
        try {
            startService(new Intent(this, PlayerService.class));
        } catch (Throwable ignored) {
            // 后台启动限制等异常不影响前台服务
        }
    }

    private void promote() {
        ensureStarted();
        try {
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIFICATION_ID, n);
            }
            foreground = true;
        } catch (Throwable t) {
            notifyError("无法进入后台播放：" + t);
        }
    }

    private void notifyError(String message) {
        for (Listener l : listeners) {
            l.onError(message);
        }
    }

    private void sync() {
        Track widgetTrack = currentTrack();
        String widgetTitle = widgetTrack == null ? getString(R.string.app_name) : widgetTrack.title;
        if (!widgetTitle.equals(lastWidgetTitle) || playing != lastWidgetPlaying) {
            lastWidgetTitle = widgetTitle;
            lastWidgetPlaying = playing;
            prefs.setWidgetState(widgetTitle, widgetTrack == null ? "" : widgetTrack.artist, playing);
            MusicWidgetProvider.refresh(this);
        }
        updateSession();
        if (foreground) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) {
                try {
                    nm.notify(NOTIFICATION_ID, buildNotification());
                } catch (Throwable ignored) {
                    // 通知失败不影响播放
                }
            }
        }
        for (Listener l : listeners) {
            l.onStateChanged();
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL_ID) != null) {
            return;
        }
        try {
            nm.deleteNotificationChannel("playback");
        } catch (Throwable ignored) {
            // 忽略
        }
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "播放控制", NotificationManager.IMPORTANCE_LOW);
        channel.setShowBadge(false);
        channel.setSound(null, null);
        nm.createNotificationChannel(channel);
    }

    private Notification buildNotification() {
        Track track = currentTrack();
        String title = track == null ? getString(R.string.app_name) : track.title;
        String text = track == null ? "" : track.artist;

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }
        if (artwork != null) {
            builder.setLargeIcon(artwork);
        }
        builder.setSmallIcon(R.drawable.ic_stat_waveform)
                .setContentTitle(title)
                .setContentText(text)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setOngoing(playing)
                .setSubText(getString(R.string.app_name))
                .setContentIntent(activityIntent())
                .addAction(action(R.drawable.ic_prev, getString(R.string.prev), ACTION_PREV))
                .addAction(action(playing ? R.drawable.ic_pause : R.drawable.ic_play,
                        getString(playing ? R.string.pause : R.string.play), ACTION_TOGGLE))
                .addAction(action(R.drawable.ic_next, getString(R.string.next), ACTION_NEXT))
                .setStyle(new Notification.MediaStyle()
                        .setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2));
        return builder.build();
    }

    private Notification.Action action(int iconRes, String label, String action) {
        PendingIntent pi = PendingIntent.getService(
                this, action.hashCode(),
                new Intent(this, PlayerService.class).setAction(action),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Action.Builder(
                Icon.createWithResource(this, iconRes), label, pi).build();
    }

    private PendingIntent activityIntent() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void updateSession() {
        if (session == null) {
            return;
        }
        Track track = currentTrack();
        if (track != null) {
            MediaMetadata.Builder meta = new MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, track.title)
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, track.artist)
                    .putString(MediaMetadata.METADATA_KEY_ALBUM, track.album)
                    .putLong(MediaMetadata.METADATA_KEY_DURATION, track.duration);
            if (artwork != null) {
                meta.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, artwork);
                meta.putBitmap(MediaMetadata.METADATA_KEY_ART, artwork);
            }
            session.setMetadata(meta.build());
        }
        int state;
        if (playing) {
            state = PlaybackState.STATE_PLAYING;
        } else if (preparing) {
            state = PlaybackState.STATE_BUFFERING;
        } else if (prepared) {
            state = PlaybackState.STATE_PAUSED;
        } else {
            state = PlaybackState.STATE_NONE;
        }
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE
                        | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_STOP
                        | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS
                        | PlaybackState.ACTION_SEEK_TO)
                .setState(state, getPosition(), playing ? 1f : 0f)
                .build());
    }

    // -------------------------------------------------------------- 音频焦点

    private AudioAttributes audioAttributes() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build();
    }

    private void grabFocus() {
        if (audioManager == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            AudioFocusRequest request = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(audioAttributes())
                    .setOnAudioFocusChangeListener(this)
                    .build();
            audioManager.requestAudioFocus(request);
        } else {
            audioManager.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }

    @Override
    public void onAudioFocusChange(int change) {
        if (change == AudioManager.AUDIOFOCUS_LOSS
                || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            if (playing) {
                resumeOnFocus = change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT;
                pauseInternal(true);
            }
        } else if (change == AudioManager.AUDIOFOCUS_GAIN) {
            if (resumeOnFocus && prepared && player != null && !playing) {
                resumeOnFocus = false;
                player.start();
                playing = true;
                promote();
                sync();
            }
        }
    }
}
