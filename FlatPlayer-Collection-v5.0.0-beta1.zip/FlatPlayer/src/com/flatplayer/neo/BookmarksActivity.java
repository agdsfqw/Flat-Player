package com.flatplayer.neo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

/** 所有歌曲的书签汇总页。 */
public class BookmarksActivity extends PlayerBindActivity {

    private final ArrayList<Row> rows = new ArrayList<>();
    private ListView list;
    private TextView empty;
    private Prefs prefs;
    private BookmarkAdapter adapter;

    static class Row {
        Track track;
        int position;
        String note;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmarks);
        prefs = new Prefs(this);
        list = findViewById(R.id.bookmark_list);
        empty = findViewById(R.id.bookmark_empty);
        adapter = new BookmarkAdapter();
        list.setAdapter(adapter);

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Row row = rows.get(position);
                startService(new Intent(BookmarksActivity.this, PlayerService.class));
                if (service != null) {
                    ArrayList<Track> queue = new ArrayList<>();
                    queue.add(row.track);
                    service.setQueue(queue, 0, row.position, true);
                } else {
                    android.widget.Toast.makeText(BookmarksActivity.this,
                            "播放服务启动中，请稍后再试",
                            android.widget.Toast.LENGTH_SHORT).show();
                }
            }
        });
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                final Row row = rows.get(position);
                new AlertDialog.Builder(BookmarksActivity.this)
                        .setTitle(R.string.bookmark_remove)
                        .setMessage(row.track.title + " · " + Track.format(row.position))
                        .setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                prefs.removeBookmark(row.track.uri, row.position);
                                load();
                            }
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show();
                return true;
            }
        });

        load();
    }

    private void load() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HashMap<String, Track> map = new HashMap<>();
                for (Track track : Library.loadAll(BookmarksActivity.this)) {
                    map.put(track.uri, track);
                }
                ArrayList<Row> result = new ArrayList<>();
                JSONObject all = prefs.allBookmarks();
                Iterator<String> keys = all.keys();
                while (keys.hasNext()) {
                    String uri = keys.next();
                    Track track = map.get(uri);
                    if (track == null) {
                        continue;
                    }
                    JSONArray positions = all.optJSONArray(uri);
                    if (positions == null) {
                        continue;
                    }
                    for (int i = 0; i < positions.length(); i++) {
                        org.json.JSONObject item = positions.optJSONObject(i);
                        Row row = new Row();
                        row.track = track;
                        row.position = item == null ? 0 : item.optInt("p");
                        row.note = item == null ? "" : item.optString("n");
                        result.add(row);
                    }
                }
                Collections.sort(result, new Comparator<Row>() {
                    @Override
                    public int compare(Row a, Row b) {
                        return a.track.title.compareToIgnoreCase(b.track.title);
                    }
                });
                final ArrayList<Row> loaded = result;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        rows.clear();
                        rows.addAll(loaded);
                        adapter.notifyDataSetChanged();
                        empty.setVisibility(rows.isEmpty() ? View.VISIBLE : View.GONE);
                    }
                });
            }
        }).start();
    }

    private class BookmarkAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public Row getItem(int position) {
            return rows.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = getLayoutInflater().inflate(R.layout.item_browse, parent, false);
            }
            Row row = rows.get(position);
            TextView title = view.findViewById(R.id.b_title);
            TextView sub = view.findViewById(R.id.b_sub);
            title.setText(row.track.title);
            String suffix = row.note == null || row.note.isEmpty() ? row.track.artist : row.note;
            sub.setText(Track.format(row.position) + " · " + suffix);
            return view;
        }
    }
}
