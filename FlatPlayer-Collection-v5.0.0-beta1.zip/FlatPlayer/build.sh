#!/usr/bin/env bash
# Sfl Player 无 Gradle 构建脚本（aapt2 + javac + d8 + zipalign + apksigner）
set -euo pipefail

PROJ="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 1) JDK：优先使用 JAVA_HOME，否则用 PATH 里的 java/javac
if [ -n "${JAVA_HOME:-}" ]; then
    export PATH="$JAVA_HOME/bin:$PATH"
fi
command -v javac >/dev/null 2>&1 || {
    echo "错误: 找不到 javac，请安装 JDK 17+ 或设置 JAVA_HOME" >&2
    exit 1
}

# 2) Android SDK
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/Android/Sdk}}"
if [ ! -d "$SDK" ]; then
    echo "错误: 找不到 Android SDK，请设置 ANDROID_SDK_ROOT（当前: $SDK）" >&2
    exit 1
fi
if [ -d "$SDK/build-tools/34.0.0" ]; then
    BT="$SDK/build-tools/34.0.0"
else
    BT="$(ls -d "$SDK"/build-tools/* 2>/dev/null | sort -V | tail -1 || true)"
fi
[ -n "${BT:-}" ] && [ -d "$BT" ] || {
    echo "错误: 找不到 build-tools（需要 34.x）" >&2
    exit 1
}
PLATFORM="$SDK/platforms/android-34/android.jar"
[ -f "$PLATFORM" ] || {
    echo "错误: 缺少 platforms/android-34，请在 SDK Manager 安装 Android 14 SDK" >&2
    exit 1
}

# 3) aapt2 若无法直接运行（例如 aarch64 主机上的 x86_64 工具），尝试 qemu
QEMU="${QEMU:-/usr/bin/qemu-x86_64-static}"
X86ROOT="${X86ROOT:-/tmp/x86root}"
USE_QEMU=0
if ! "$BT/aapt2" version >/dev/null 2>&1; then
    if [ -x "$QEMU" ] && [ -d "$X86ROOT" ]; then
        USE_QEMU=1
    else
        echo "错误: aapt2 无法运行；非 x86_64 主机可安装 qemu-user-static 并设置 QEMU/X86ROOT" >&2
        exit 1
    fi
fi

bt() {
    local tool="$1"
    shift
    if [ "$USE_QEMU" = "1" ]; then
        "$QEMU" -L "$X86ROOT" "$BT/$tool" "$@"
    else
        "$BT/$tool" "$@"
    fi
}

VERSION_CODE="$(sed -n 's/.*android:versionCode="\([0-9]*\)".*/\1/p' "$PROJ/AndroidManifest.xml" | head -1)"
VERSION_NAME="$(sed -n 's/.*android:versionName="\([^"]*\)".*/\1/p' "$PROJ/AndroidManifest.xml" | head -1)"
[ -n "$VERSION_CODE" ] && [ -n "$VERSION_NAME" ] || {
    echo "错误: 无法从 AndroidManifest.xml 读取版本号" >&2
    exit 1
}

OUT="$PROJ/build"
APK="$PROJ/FlatPlayer.apk"
rm -rf "$OUT"
mkdir -p "$OUT/compiled" "$OUT/gen" "$OUT/classes" "$OUT/dex"

echo "[1/6] 编译资源"
bt aapt2 compile --dir "$PROJ/res" -o "$OUT/compiled/res.zip"

echo "[2/6] 链接资源"
bt aapt2 link \
    -o "$OUT/unsigned.apk" \
    -I "$PLATFORM" \
    --manifest "$PROJ/AndroidManifest.xml" \
    --java "$OUT/gen" \
    --min-sdk-version 23 \
    --target-sdk-version 34 \
    --version-code "$VERSION_CODE" \
    --version-name "$VERSION_NAME" \
    -A "$PROJ/assets" \
    "$OUT/compiled/res.zip"

echo "[3/6] 编译 Java"
find "$PROJ/src" "$OUT/gen" -name '*.java' > "$OUT/sources.txt"
javac -source 8 -target 8 -bootclasspath "$PLATFORM" -encoding UTF-8 \
    -d "$OUT/classes" @"$OUT/sources.txt"

echo "[4/6] 生成 classes.dex"
find "$OUT/classes" -name '*.class' > "$OUT/classes.txt"
R8_JAR="${R8_JAR:-$PROJ/tools/r8.jar}"
if [ ! -f "$R8_JAR" ]; then
    R8_JAR="$BT/lib/d8.jar"
fi
[ -f "$R8_JAR" ] || {
    echo "错误: 找不到 R8/D8，请设置 R8_JAR 指向 r8.jar" >&2
    exit 1
}
java -cp "$R8_JAR" com.android.tools.r8.D8 --release --min-api 23 --lib "$PLATFORM" \
    --output "$OUT/dex" @"$OUT/classes.txt"
(cd "$OUT/dex" && bt aapt add "$OUT/unsigned.apk" classes.dex > /dev/null)

echo "[5/6] 对齐"
bt zipalign -f -p 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

echo "[6/6] 签名"
if [ -n "${RELEASE_KS:-}" ] && [ -f "$RELEASE_KS" ]; then
    KS="$RELEASE_KS"
    ALIAS="${RELEASE_ALIAS:-flatplayer}"
    STOREPASS="${RELEASE_KS_PASS:?RELEASE_KS_PASS 未设置}"
    KEYPASS="${RELEASE_KEY_PASS:-$STOREPASS}"
    echo "使用 release 签名: $KS"
else
    KS="$PROJ/debug.keystore"
    ALIAS=androiddebugkey
    STOREPASS=android
    KEYPASS=android
    if [ ! -f "$KS" ]; then
        echo "未找到 debug.keystore，生成一个仅用于本地调试的签名密钥"
        keytool -genkeypair -keystore "$KS" -storepass android -keypass android \
            -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 \
            -dname "CN=Android Debug,O=Android,C=US" > /dev/null 2>&1
    fi
fi
"$BT/apksigner" sign --ks "$KS" --ks-key-alias "$ALIAS" \
    --ks-pass "pass:$STOREPASS" --key-pass "pass:$KEYPASS" \
    --out "$APK" "$OUT/aligned.apk"
"$BT/apksigner" verify "$APK"

echo
echo "构建完成: $APK"
ls -lh "$APK"
