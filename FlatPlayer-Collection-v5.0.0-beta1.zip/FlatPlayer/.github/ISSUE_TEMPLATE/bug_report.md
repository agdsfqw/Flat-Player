---
name: Bug 报告
about: 崩溃、播放异常、数据问题
title: "[Bug] "
labels: bug
---

## 版本

- Flat Player 版本：
- Android 版本：
- 机型：

## 现象

（发生了什么）

## 复现步骤

1.
2.
3.

## 期望结果

## 日志

如有 `Download/flat_crash_*.txt` 或 `Android/data/com.flatplayer.neo/files/last_crash.txt`，请附上。
