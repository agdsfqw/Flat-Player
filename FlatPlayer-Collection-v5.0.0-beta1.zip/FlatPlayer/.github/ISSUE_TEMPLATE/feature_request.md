---
name: 功能建议
about: 希望增加或改进的功能
title: "[Feature] "
labels: enhancement
---

## 需求

## 使用场景

## 是否接受“只做核心、不加依赖”的限制
